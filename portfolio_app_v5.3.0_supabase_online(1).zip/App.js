import { supabase } from './supabase';
import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  Image,
  Modal,
  SafeAreaView,
  StatusBar,
  Linking,
  ActivityIndicator,
  Alert,
  TextInput,
  Animated,
  Dimensions,
  KeyboardAvoidingView,
  Platform,
  RefreshControl,
  Switch
} from 'react-native';
import { WebView } from 'react-native-webview';
import Svg, { Rect, Path, Circle } from 'react-native-svg';
import * as ImagePicker from 'expo-image-picker';
import AsyncStorage from '@react-native-async-storage/async-storage';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const STORAGE_KEY = '@portfolio_projects_v1';
const FOLLOWED_KEY = '@followed_designers_v1';
const HIDE_LIKED_KEY = '@hide_liked_portfolios_v1';
const USER_PROFILE_KEY = '@user_profile_v1';

const RESPONSIVE_PROFILE_CARD_WIDTH = (SCREEN_WIDTH - 40 - 16) / 2;

const ALL_UIUX_CATEGORIES_MASTER = [
  'AI & Machine Learning',
  'Adobe XD',
  'Android',
  'AR/VR Interface',
  'Automotive HMI',
  'Branding & Identity',
  'Crypto & Web3',
  'Dashboard & Analytics',
  'Design System',
  'Desktop App',
  'E-Commerce',
  'EdTech',
  'Entertainment',
  'Figma',
  'Figma Prototype',
  'Figma Tokens',
  'FinTech',
  'Fitness & Sports',
  'Food & Beverage',
  'Framer',
  'Gaming & Esports',
  'Healthcare',
  'InsurTech',
  'iOS',
  'IoT & Smart Home',
  'LegalTech',
  'Logistics & Supply Chain',
  'Micro-interactions',
  'Mobile App',
  'Protopie',
  'Real Estate',
  'Responsive Web',
  'Rive Animation',
  'SaaS',
  'Social Media',
  'Spatial Computing',
  'Spline 3D',
  'Telehealth',
  'Travel & Hospitality',
  'User Research & Persona',
  'VisionOS',
  'WatchOS & Wearables',
  'Web Design',
  'Wireframing & User Flow',
  '3D Assets & Animation'
].sort();

const DEFAULT_POPULAR_CATEGORY_CHIPS = [
  'Mobile App', 'Web Design', 'Design System', 'FinTech',
  'Healthcare', 'E-Commerce', 'SaaS', 'AI & Machine Learning',
  'Dashboard & Analytics', 'Figma Prototype'
];

// SVG Icons
const MobileIconSVG = React.memo(() => (
  <Svg width="18" height="18" viewBox="0 0 24 24" fill="none">
    <Rect x="6" y="2" width="12" height="20" rx="2.5" stroke="#FFFFFF" strokeWidth="2" />
    <Path d="M12 18h.01" stroke="#FFFFFF" strokeWidth="2.5" strokeLinecap="round" />
  </Svg>
));

const DesktopIconSVG = React.memo(() => (
  <Svg width="18" height="18" viewBox="0 0 24 24" fill="none">
    <Rect x="2" y="3" width="20" height="13" rx="2" stroke="#FFFFFF" strokeWidth="2" />
    <Path d="M8 21h8M12 16v5" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" />
  </Svg>
));

const HeartIconSVG = React.memo(({ liked }) => (
  <Svg width="22" height="22" viewBox="0 0 24 24" fill={liked ? '#EF4444' : 'none'}>
    <Path
      d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"
      stroke={liked ? '#EF4444' : '#FFFFFF'}
      strokeWidth="2"
      strokeLinejoin="round"
    />
  </Svg>
));

const EyeViewIconSVG = React.memo(() => (
  <Svg width="18" height="18" viewBox="0 0 24 24" fill="none">
    <Path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <Circle cx="12" cy="12" r="3" stroke="#94A3B8" strokeWidth="2"/>
  </Svg>
));

const UserFollowIconSVG = React.memo(({ following }) => (
  <Svg width="20" height="20" viewBox="0 0 24 24" fill="none">
    <Path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" stroke={following ? '#C084FC' : '#FFFFFF'} strokeWidth="2" strokeLinecap="round" />
    <Circle cx="8.5" cy="7" r="4" stroke={following ? '#C084FC' : '#FFFFFF'} strokeWidth="2" />
    <Path d={following ? "M17 11l2 2 4-4" : "M20 8v6M23 11h-6"} stroke={following ? '#10B981' : '#FFFFFF'} strokeWidth="2" strokeLinecap="round" />
  </Svg>
));

const BellSVG = React.memo(() => (
  <Svg width="18" height="18" viewBox="0 0 24 24" fill="none">
    <Path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 0 1-3.46 0" stroke="#D8B4FE" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
));

const CogWheelSVG = React.memo(() => (
  <Svg width="19" height="19" viewBox="0 0 24 24" fill="none">
    <Path
      d="M19.14 12.94C19.18 12.63 19.2 12.32 19.2 12C19.2 11.68 19.18 11.37 19.14 11.06L21.16 9.48C21.34 9.34 21.39 9.09 21.28 8.89L19.36 5.56C19.25 5.36 19 5.28 18.79 5.36L16.41 6.22C15.92 5.84 15.39 5.53 14.81 5.29L14.45 2.76C14.41 2.54 14.22 2.38 14 2.38H10C9.78 2.38 9.59 2.54 9.55 2.76L9.19 5.29C8.61 5.53 8.08 5.85 7.59 6.22L5.21 5.36C5 5.28 4.75 5.36 4.64 5.56L2.72 8.89C2.61 9.09 2.66 9.34 2.84 9.48L4.86 11.06C4.82 11.37 4.8 11.69 4.8 12C4.8 12.31 4.82 12.63 4.86 12.94L2.84 14.52C2.66 14.66 2.61 14.91 2.72 15.11L4.64 18.44C4.75 18.64 5 18.72 5.21 18.64L7.59 17.78C8.08 18.16 8.61 18.47 9.19 18.71L9.55 21.24C9.59 21.46 9.78 21.62 10 21.62H14C14.22 21.62 14.41 21.46 14.45 21.24L14.81 18.71C15.39 18.47 15.92 18.16 16.41 17.78L18.79 18.64C19 18.72 19.25 18.64 19.36 18.44L21.28 15.11C21.39 14.91 21.34 14.66 21.16 14.52L19.14 12.94ZM12 15.5C10.34 15.5 9 14.16 9 12.5C9 10.84 10.34 9.5 12 9.5C13.66 9.5 15 10.84 15 12.5C15 14.16 13.66 15.5 12 15.5Z"
      fill="#D8B4FE"
    />
  </Svg>
));

const ChevronRightSVG = React.memo(({ color = "#8B5CF6", size = 18 }) => (
  <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
    <Path d="M9 18l6-6-6-6" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
));

const ChevronLeftSVG = React.memo(({ color = "#94A3B8", size = 18 }) => (
  <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
    <Path d="M15 18l-6-6 6-6" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
));

const ChevronUpSVG = React.memo(({ color = "#FFFFFF", size = 20 }) => (
  <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
    <Path d="M18 15l-6-6-6 6" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
));

const ClearTextXSVG = React.memo(() => (
  <Svg width="14" height="14" viewBox="0 0 24 24" fill="none">
    <Path d="M18 6L6 18M6 6l12 12" stroke="#94A3B8" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
));

const ForYouSVG = React.memo(({ active }) => (
  <Svg width="22" height="22" viewBox="0 0 24 24" fill="none">
    <Path
      d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
      stroke={active ? '#8B5CF6' : '#94A3B8'}
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      fill={active ? 'rgba(139, 92, 246, 0.25)' : 'none'}
    />
  </Svg>
));

const FollowedTabSVG = React.memo(({ active }) => (
  <Svg width="22" height="22" viewBox="0 0 24 24" fill="none">
    <Path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" stroke={active ? '#8B5CF6' : '#94A3B8'} strokeWidth="2" strokeLinecap="round" />
    <Circle cx="8.5" cy="7" r="4" stroke={active ? '#8B5CF6' : '#94A3B8'} strokeWidth="2" />
    <Path d="M20 8v6M23 11h-6" stroke={active ? '#8B5CF6' : '#94A3B8'} strokeWidth="2" strokeLinecap="round" />
  </Svg>
));

const PlusSVG = React.memo(() => (
  <Svg width="20" height="20" viewBox="0 0 24 24" fill="none">
    <Path d="M12 5V19M5 12H19" stroke="#FFFFFF" strokeWidth="2.5" strokeLinecap="round" />
  </Svg>
));

const SearchSVG = React.memo(({ active }) => (
  <Svg width="22" height="22" viewBox="0 0 24 24" fill="none">
    <Circle cx="11" cy="11" r="7" stroke={active ? '#8B5CF6' : '#94A3B8'} strokeWidth="2" />
    <Path d="M20 20L16 16" stroke={active ? '#8B5CF6' : '#94A3B8'} strokeWidth="2" strokeLinecap="round" />
  </Svg>
));

const ProfileSVG = React.memo(({ active }) => (
  <Svg width="22" height="22" viewBox="0 0 24 24" fill="none">
    <Circle cx="12" cy="7" r="4" stroke={active ? '#8B5CF6' : '#94A3B8'} strokeWidth="2" />
    <Path d="M4 21C4 17.134 7.58172 14 12 14C16.4183 14 20 17.134 20 21" stroke={active ? '#8B5CF6' : '#94A3B8'} strokeWidth="2" strokeLinecap="round" />
  </Svg>
));

const Grid2x2SVG = React.memo(() => (
  <Svg width="18" height="18" viewBox="0 0 24 24" fill="none">
    <Rect x="3" y="3" width="8" height="8" rx="2" stroke="#FFFFFF" strokeWidth="2" />
    <Rect x="13" y="3" width="8" height="8" rx="2" stroke="#FFFFFF" strokeWidth="2" />
    <Rect x="13" y="13" width="8" height="8" rx="2" stroke="#FFFFFF" strokeWidth="2" />
    <Rect x="3" y="13" width="8" height="8" rx="2" stroke="#FFFFFF" strokeWidth="2" />
  </Svg>
));

const ShareIconSVG = React.memo(() => (
  <Svg width="18" height="18" viewBox="0 0 24 24" fill="none">
    <Circle cx="18" cy="5" r="3" stroke="#D8B4FE" strokeWidth="2" />
    <Circle cx="6" cy="12" r="3" stroke="#D8B4FE" strokeWidth="2" />
    <Circle cx="18" cy="19" r="3" stroke="#D8B4FE" strokeWidth="2" />
    <Path d="M8.59 13.51l6.83 3.98M15.41 6.51l-6.82 3.98" stroke="#D8B4FE" strokeWidth="2" />
  </Svg>
));

const EditIconSVG = React.memo(() => (
  <Svg width="18" height="18" viewBox="0 0 24 24" fill="none">
    <Path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" stroke="#D8B4FE" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <Path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" stroke="#D8B4FE" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </Svg>
));

const TrashIconSVG = React.memo(() => (
  <Svg width="18" height="18" viewBox="0 0 24 24" fill="none">
    <Path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" stroke="#EF4444" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </Svg>
));

const SearchChipSVG = React.memo(() => (
  <Svg width="13" height="13" viewBox="0 0 24 24" fill="none">
    <Circle cx="11" cy="11" r="7" stroke="#D8B4FE" strokeWidth="2" />
    <Path d="M20 20L16 16" stroke="#D8B4FE" strokeWidth="2" strokeLinecap="round" />
  </Svg>
));

const LocationPinSVG = React.memo(() => (
  <Svg width="14" height="14" viewBox="0 0 24 24" fill="none">
    <Path d="M12 2C8.13 2 5 5.13 5 9C5 14.25 12 22 12 22C12 22 19 14.25 19 9C19 5.13 15.87 2 12 2Z" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <Circle cx="12" cy="9" r="2.5" stroke="#94A3B8" strokeWidth="2"/>
  </Svg>
));

const WarningTriangleSVG = React.memo(() => (
  <Svg width="20" height="20" viewBox="0 0 24 24" fill="none">
    <Path d="M10.29 3.86L1.82 18C1.64537 18.3024 1.55296 18.6453 1.55199 18.9945C1.55103 19.3437 1.64154 19.6874 1.81445 19.991C1.98737 20.2946 2.23652 20.5478 2.53684 20.7252C2.83716 20.9026 3.1783 20.9981 3.52 21H20.48C20.8217 20.9981 21.1628 20.9026 21.4632 20.7252C21.7635 20.5478 22.0126 20.2946 22.1855 19.991C22.3585 19.6874 22.449 19.3437 22.448 18.9945C22.447 18.6453 22.3546 18.3024 22.18 18L13.71 3.86C13.5317 3.56613 13.2807 3.32314 12.9812 3.15448C12.6817 2.98582 12.3437 2.89746 12 2.89746C11.6563 2.89746 11.3183 2.98582 11.0188 3.15448C10.7193 3.32314 10.4683 3.56613 10.29 3.86Z" stroke="#EF4444" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <Path d="M12 9V13" stroke="#EF4444" strokeWidth="2" strokeLinecap="round"/>
    <Path d="M12 17H12.01" stroke="#EF4444" strokeWidth="2" strokeLinecap="round"/>
  </Svg>
));

const ImageIconSVG = React.memo(() => (
  <Svg width="28" height="28" viewBox="0 0 24 24" fill="none">
    <Rect x="3" y="3" width="18" height="18" rx="3" stroke="#8B5CF6" strokeWidth="2" />
    <Circle cx="8.5" cy="8.5" r="1.5" fill="#8B5CF6" />
    <Path d="M21 15L16 10L5 21" stroke="#8B5CF6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
));

const CameraIconSVG = React.memo(() => (
  <Svg width="20" height="20" viewBox="0 0 24 24" fill="none">
    <Path d="M23 19C23 19.5304 22.7893 20.0391 22.4142 20.4142C22.0391 20.7893 21.5304 21 21 21H3C2.46957 21 1.96086 20.7893 1.58579 20.4142C1.21071 20.0391 1 19.5304 1 19V8C1 7.46957 1.21071 6.96086 1.58579 6.58579C1.96086 6.21071 2.46957 6 3 6H7L9 3H15L17 6H21C21.5304 6 22.0391 6.21071 22.4142 6.58579C22.7893 6.96086 23 7.46957 23 8V19Z" stroke="#8B5CF6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <Circle cx="12" cy="13" r="4" stroke="#8B5CF6" strokeWidth="2"/>
  </Svg>
));

const DetailsStepSVG = React.memo(({ color }) => (
  <Svg width="18" height="18" viewBox="0 0 24 24" fill="none">
    <Path d="M14 2H6C4.89543 2 4 2.89543 4 4V20C4 21.1046 4.89543 22 6 22H18C19.1046 22 20 21.1046 20 20V8L14 2Z" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <Path d="M14 2V8H20" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <Path d="M16 13H8" stroke={color} strokeWidth="2" strokeLinecap="round"/>
    <Path d="M16 17H8" stroke={color} strokeWidth="2" strokeLinecap="round"/>
  </Svg>
));

const LinksStepSVG = React.memo(({ color }) => (
  <Svg width="18" height="18" viewBox="0 0 24 24" fill="none">
    <Path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <Path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </Svg>
));

const MediaStepSVG = React.memo(({ color }) => (
  <Svg width="18" height="18" viewBox="0 0 24 24" fill="none">
    <Rect x="3" y="3" width="18" height="18" rx="2" stroke={color} strokeWidth="2" />
    <Circle cx="8.5" cy="8.5" r="1.5" fill={color} />
    <Path d="M21 15l-5-5L5 21" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
));

const ReviewStepSVG = React.memo(({ color }) => (
  <Svg width="18" height="18" viewBox="0 0 24 24" fill="none">
    <Path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <Path d="M22 4L12 14.01l-3-3" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </Svg>
));

const CheckIconSVG = React.memo(() => (
  <Svg width="18" height="18" viewBox="0 0 24 24" fill="none">
    <Path d="M20 6L9 17l-5-5" stroke="#10B981" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
  </Svg>
));

// SOCIAL BRAND LOGO SVGS FOR AUTO DETECTED LINKS
const FigmaLogoSVG = React.memo(() => (
  <Svg width="16" height="16" viewBox="0 0 24 24" fill="none">
    <Path d="M12 12a3 3 0 1 1 6 0 3 3 0 0 1-6 0z" fill="#1ABCFE" />
    <Path d="M6 18a3 3 0 0 1 3-3h3v3a3 3 0 0 1-6 0z" fill="#0ACF83" />
    <Path d="M6 12a3 3 0 0 1 3-3h3v6H9a3 3 0 0 1-3-3z" fill="#A259FF" />
    <Path d="M6 6a3 3 0 0 1 3-3h3v6H9a3 3 0 0 1-3-3z" fill="#F24E1E" />
    <Path d="M12 3h3a3 3 0 0 1 0 6h-3V3z" fill="#FF7262" />
  </Svg>
));

const DribbbleLogoSVG = React.memo(() => (
  <Svg width="16" height="16" viewBox="0 0 24 24" fill="none">
    <Circle cx="12" cy="12" r="9" stroke="#EA4C89" strokeWidth="2" />
    <Path d="M12 3c3 3 5 7 5 9M3.6 9c3 1 7 2 11 0M4.5 16.5c3-2 7-3 12-1" stroke="#EA4C89" strokeWidth="2" strokeLinecap="round" />
  </Svg>
));

const LinkedInLogoSVG = React.memo(() => (
  <Svg width="16" height="16" viewBox="0 0 24 24" fill="none">
    <Path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-4 0v7h-4v-7a6 6 0 0 1 6-6zM2 9h4v12H2z" fill="#0A66C2" />
    <Circle cx="4" cy="4" r="2" fill="#0A66C2" />
  </Svg>
));

const GitHubLogoSVG = React.memo(() => (
  <Svg width="16" height="16" viewBox="0 0 24 24" fill="none">
    <Path d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.258-1.11-1.594-1.11-1.594-.908-.62.069-.608.069-.608 1.003.07 1.53 1.032 1.53 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" fill="#FFFFFF" />
  </Svg>
));

const TwitterLogoSVG = React.memo(() => (
  <Svg width="16" height="16" viewBox="0 0 24 24" fill="none">
    <Path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.4 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z" fill="#1DA1F2" />
  </Svg>
));

const YouTubeLogoSVG = React.memo(() => (
  <Svg width="16" height="16" viewBox="0 0 24 24" fill="none">
    <Path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-1.96C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 1.96A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-1.96 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.37z" fill="#FF0000" />
    <Path d="M9.75 15.02l5.75-3.27-5.75-3.27v6.54z" fill="#FFFFFF" />
  </Svg>
));

const GlobeIconSVG = React.memo(() => (
  <Svg width="16" height="16" viewBox="0 0 24 24" fill="none">
    <Circle cx="12" cy="12" r="9" stroke="#94A3B8" strokeWidth="2" />
    <Path d="M3.6 9h16.8M3.6 15h16.8M12 3a15.3 15.3 0 0 1 4 9 15.3 15.3 0 0 1-4 9 15.3 15.3 0 0 1-4-9 15.3 15.3 0 0 1 4-9z" stroke="#94A3B8" strokeWidth="2" />
  </Svg>
));

const getSocialLogoSVG = (url) => {
  if (!url) return <GlobeIconSVG />;
  const lower = url.toLowerCase();
  if (lower.includes('figma.com')) return <FigmaLogoSVG />;
  if (lower.includes('dribbble.com')) return <DribbbleLogoSVG />;
  if (lower.includes('linkedin.com')) return <LinkedInLogoSVG />;
  if (lower.includes('github.com')) return <GitHubLogoSVG />;
  if (lower.includes('twitter.com') || lower.includes('x.com')) return <TwitterLogoSVG />;
  if (lower.includes('youtube.com') || lower.includes('youtu.be')) return <YouTubeLogoSVG />;
  return <GlobeIconSVG />;
};

// Popular Keywords
const POPULAR_KEYWORDS = [
  'Healthcare', 'E-Commerce', 'Design System',
  'FinTech', 'Dark Mode', 'Mobile Booking',
  'SaaS', 'AI Analytics', '3D Components'
];

// Initial Notifications
const INITIAL_NOTIFICATIONS = [
  { id: 'n1', type: 'like', user: 'Maya Lin', action: 'liked your portfolio package', target: 'The Vein Clinic & Ace Vantage', time: '2m ago', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80' },
  { id: 'n2', type: 'follow', user: 'Alex Rivera', action: 'started following your profile', target: '', time: '1h ago', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80' },
  { id: 'n3', type: 'like', user: 'Elena Rostova', action: 'liked your portfolio package', target: 'Design System Tokens & Guidelines', time: '3h ago', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80' },
  { id: 'n4', type: 'follow', user: 'Marcus Chen', action: 'started following your profile', target: '', time: '1d ago', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80' }
];

// 15 Mockup Designers Profiles
const POPULAR_DESIGNERS = [
  { id: 'd1', name: 'Iqbal Aprianda Putra', role: 'UI/UX & Web Content Designer', location: 'South Jakarta, Jakarta, Indonesia', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80', figma: 'https://www.figma.com/@iqbalaprianda', bio: 'Web Content Designer at Moonbow Lab based in Jakarta, specializing in design systems, mobile apps, and interactive Figma prototypes.', followersCount: 1420, followingCount: 280, links: ['https://www.figma.com/@iqbalaprianda', 'https://dribbble.com', 'https://linkedin.com'] },
  { id: 'd2', name: 'Maya Lin', role: 'Lead Mobile Product Designer', location: 'Singapore', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80', figma: 'https://www.figma.com', bio: 'Crafting accessible mobile banking experiences and micro-animations.', followersCount: 2890, followingCount: 310, links: ['https://dribbble.com', 'https://linkedin.com'] },
  { id: 'd3', name: 'Alex Rivera', role: 'Design System Architect', location: 'San Francisco, CA', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80', figma: 'https://www.figma.com', bio: 'Building scalable Figma component libraries and cross-platform design tokens.', followersCount: 3410, followingCount: 190, links: ['https://github.com', 'https://www.figma.com'] },
  { id: 'd4', name: 'Elena Rostova', role: 'Senior FinTech UX Lead', location: 'Berlin, Germany', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80', figma: 'https://www.figma.com', bio: 'Pioneering seamless digital wallet flows and cross-border payment interfaces.', followersCount: 1980, followingCount: 420, links: ['https://twitter.com', 'https://linkedin.com'] },
  { id: 'd5', name: 'Marcus Chen', role: 'AI Interface Specialist', location: 'Toronto, Canada', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80', figma: 'https://www.figma.com', bio: 'Designing human-AI collaborative tools and prompt engineering dashboards.', followersCount: 2150, followingCount: 150, links: ['https://github.com', 'https://youtube.com'] },
  { id: 'd6', name: 'Sophia Patel', role: 'Healthcare UX Specialist', location: 'London, UK', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80', figma: 'https://www.figma.com', bio: 'Empathetic medical consultations and patient monitoring mobile apps.', followersCount: 1760, followingCount: 230, links: ['https://linkedin.com'] },
  { id: 'd7', name: 'David Kim', role: 'Automotive HMI Designer', location: 'Seoul, South Korea', avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80', figma: 'https://www.figma.com', bio: 'Next-gen electric vehicle digital cockpit displays and dashboard controls.', followersCount: 1240, followingCount: 110, links: ['https://youtube.com'] },
  { id: 'd8', name: 'Amara Okafor', role: 'SaaS Design Lead', location: 'Lagos, Nigeria', avatar: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=150&auto=format&fit=crop&q=80', figma: 'https://www.figma.com', bio: 'Simplifying complex enterprise cloud analytics into clean visual workflows.', followersCount: 1890, followingCount: 290, links: ['https://dribbble.com'] },
  { id: 'd9', name: 'Lucas Silva', role: 'AR/VR Spatial UX Engineer', location: 'São Paulo, Brazil', avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80', figma: 'https://www.figma.com', bio: 'Spatial computing interfaces and VisionOS immersive prototypes.', followersCount: 950, followingCount: 85, links: ['https://github.com'] },
  { id: 'd10', name: 'Hannah Abbott', role: 'E-Commerce Conversion Lead', location: 'Melbourne, Australia', avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80', figma: 'https://www.figma.com', bio: 'High-converting mobile checkout flows and retail web design.', followersCount: 2670, followingCount: 340, links: ['https://linkedin.com'] },
  { id: 'd11', name: 'Viktor Vance', role: '3D Motion & Interaction Designer', location: 'Amsterdam, Netherlands', avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80', figma: 'https://www.figma.com', bio: 'Interactive 3D web assets and fluid micro-animations in Figma.', followersCount: 1530, followingCount: 175, links: ['https://youtube.com'] },
  { id: 'd12', name: 'Chloe Dubois', role: 'Brand Identity & Design Token Lead', location: 'Paris, France', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80', figma: 'https://www.figma.com', bio: 'Blending luxury typography scales with modular design component libraries.', followersCount: 3120, followingCount: 410, links: ['https://dribbble.com'] },
  { id: 'd13', name: 'Kenji Sato', role: 'Gaming & Esports UI Lead', location: 'Tokyo, Japan', avatar: 'https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?w=150&auto=format&fit=crop&q=80', figma: 'https://www.figma.com', bio: 'High-FPS HUD displays and interactive gaming community platforms.', followersCount: 2040, followingCount: 220, links: ['https://twitter.com'] },
  { id: 'd14', name: 'Zoe Martinez', role: 'EdTech & Learning UX Designer', location: 'Barcelona, Spain', avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80', figma: 'https://www.figma.com', bio: 'Gamified learning apps for mobile students and online course portals.', followersCount: 1380, followingCount: 160, links: ['https://linkedin.com'] },
  { id: 'd15', name: "Liam O'Connor", role: 'IoT & Smart Home UX Lead', location: 'Dublin, Ireland', avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=150&auto=format&fit=crop&q=80', figma: 'https://www.figma.com', bio: 'Designing unified smart home hubs and wearable device mobile companion apps.', followersCount: 1190, followingCount: 140, links: ['https://github.com'] }
];

// Initial projects
const INITIAL_PROJECTS = [
  { id: 'p1', title: 'The Vein Clinic & Ace Vantage', designer: 'Iqbal Aprianda Putra', designerAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80', category: 'Mobile App', categories: ['Mobile App', 'Healthcare'], liked: true, likesCount: 142, visitsCount: 1280, figmaProfile: 'https://www.figma.com/@iqbalaprianda', figmaProto: 'https://www.figma.com/proto/C6HfIf87EA59vPHeuUHBFh/the-vein-clinic?node-id=565-520&p=f&viewport=1385%2C332%2C0.07&t=4S1O1IMDPBYueZW6-1&scaling=min-zoom&content-scaling=fixed&starting-point-node-id=565%3A520&page-id=565%3A518', desktopProto: 'https://www.figma.com/proto/dLhnua7s2MqhxgHqBGs550/ace-vantage?node-id=145-4194&t=XN2AKMQuauw06MyW-1', figmaFile: 'https://www.figma.com/design/C6HfIf87EA59vPHeuUHBFh/the-vein-clinic?node-id=565-518', brief: 'A specialized healthcare & clinical application designed to streamline patient consultations.', cover: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&auto=format&fit=crop&q=80', images: ['https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&auto=format&fit=crop&q=80'], videoLinks: [], caseStudy: 'Clinical Consultation UX' },
  { id: 'p2', title: 'Design System Tokens & Guidelines', designer: 'Iqbal Aprianda Putra', designerAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80', category: 'Design System', categories: ['Design System', 'Figma Tokens'], liked: true, likesCount: 98, visitsCount: 850, figmaProfile: 'https://www.figma.com/@iqbalaprianda', figmaProto: '', desktopProto: '', figmaFile: 'https://www.figma.com/design/C6HfIf87EA59vPHeuUHBFh/the-vein-clinic?node-id=565-518', brief: 'Comprehensive design tokens, typography scales, and component guidelines.', cover: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?w=800&auto=format&fit=crop&q=80', images: ['https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?w=800&auto=format&fit=crop&q=80'], videoLinks: [], caseStudy: 'Tokens & Governance' },
  { id: 'p3', title: 'Jakarta Transit Ticket App', designer: 'Iqbal Aprianda Putra', designerAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80', category: 'Mobile App', categories: ['Mobile App', 'Logistics & Supply Chain'], liked: true, likesCount: 210, visitsCount: 1640, figmaProfile: 'https://www.figma.com', figmaProto: 'https://www.figma.com', desktopProto: '', figmaFile: '', brief: 'Contactless train ticket purchasing and station route planner.', cover: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=800&auto=format&fit=crop&q=80', images: ['https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=800&auto=format&fit=crop&q=80'], videoLinks: [], caseStudy: 'Transit Accessibility' },
  { id: 'p4', title: 'Ace Vantage E-Commerce', designer: 'Maya Lin', designerAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=100&auto=format&fit=crop&q=80', category: 'Web Design', categories: ['Web Design', 'E-Commerce'], liked: true, likesCount: 175, visitsCount: 1420, figmaProfile: 'https://www.figma.com', figmaProto: '', desktopProto: 'https://www.figma.com/proto/dLhnua7s2MqhxgHqBGs550/ace-vantage?node-id=145-4194&t=XN2AKMQuauw06MyW-1', figmaFile: '', brief: 'Enterprise 1440px desktop e-commerce platform for equipment procurement.', cover: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&auto=format&fit=crop&q=80', images: ['https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&auto=format&fit=crop&q=80'], videoLinks: [], caseStudy: 'Desktop Optimization' },
  { id: 'p5', title: 'Singapore DBS Neo Mobile Banking', designer: 'Maya Lin', designerAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=100&auto=format&fit=crop&q=80', category: 'FinTech', categories: ['FinTech', 'iOS'], liked: true, likesCount: 310, visitsCount: 2890, figmaProfile: 'https://www.figma.com', figmaProto: 'https://www.figma.com', desktopProto: '', figmaFile: 'https://www.figma.com/design/dbs-neo-banking', brief: 'Accessible mobile banking experience with biometrics and instant transfers.', cover: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?w=800&auto=format&fit=crop&q=80', images: ['https://images.unsplash.com/photo-1563986768609-322da13575f3?w=800&auto=format&fit=crop&q=80'], videoLinks: [], caseStudy: 'FinTech Security' }
];

// Memoized Project Card Component
const ProjectCard = React.memo(({
  item,
  onPress,
  onToggleLike,
  onOpenDesignerProfile,
  onToggleFollow,
  isFollowing,
  customWidth,
  hideBrief = false,
  isTwoRowCard = false
}) => (
  <TouchableOpacity
    style={[
      styles.card,
      customWidth ? { width: customWidth } : null,
      isTwoRowCard && styles.cardCompactProfile
    ]}
    activeOpacity={0.88}
    onPress={() => onPress(item)}
  >
    <View style={[styles.thumbnailContainer, isTwoRowCard && styles.thumbnailContainerCompact]}>
      <Image source={{ uri: item.cover }} style={styles.cardCover} />
      <View style={styles.prototypeBadgesRow}>
        {item.figmaProto ? (
          <View style={styles.protoBadgeIconOnly}>
            <MobileIconSVG />
          </View>
        ) : null}
        {item.desktopProto ? (
          <View style={styles.protoBadgeIconOnly}>
            <DesktopIconSVG />
          </View>
        ) : null}
      </View>
    </View>

    <View style={[styles.cardBody, isTwoRowCard && styles.cardBodyCompact]}>
      <View style={styles.titleRow}>
        <Text style={[styles.cardTitle, isTwoRowCard && styles.cardTitleCompact]} numberOfLines={2}>{item.title}</Text>
        {onToggleLike ? (
          <TouchableOpacity style={styles.likeButtonRightAligned} onPress={() => onToggleLike(item.id)}>
            <HeartIconSVG liked={item.liked} />
          </TouchableOpacity>
        ) : null}
      </View>

      {!hideBrief && (
        <Text style={styles.cardDesc} numberOfLines={2}>{item.brief}</Text>
      )}

      <View style={styles.designerRowWithFollow}>
        <TouchableOpacity
          style={styles.designerRowLeftCol}
          activeOpacity={0.7}
          onPress={() => onOpenDesignerProfile && onOpenDesignerProfile(item.designer)}
        >
          <Image source={{ uri: item.designerAvatar }} style={styles.designerAvatar} />
          <Text style={styles.cardDesignerName} numberOfLines={2}>{item.designer}</Text>
        </TouchableOpacity>

        {onToggleFollow && (
          <TouchableOpacity
            style={[styles.cardFollowBtnRight, isFollowing && styles.cardFollowBtnRightActive]}
            onPress={() => onToggleFollow(item.designer)}
          >
            <Text style={[styles.cardFollowBtnText, isFollowing && styles.cardFollowBtnTextActive]}>
              {isFollowing ? 'Following' : '+ Follow Back'}
            </Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  </TouchableOpacity>
));

const ProjectGrid = React.memo(({ items, onPress, onToggleLike, onOpenDesignerProfile, onToggleFollow, followedDesigners }) => (
  <View style={styles.grid}>
    {items.map((item) => (
      <ProjectCard
        key={item.id}
        item={item}
        onPress={onPress}
        onToggleLike={onToggleLike}
        onOpenDesignerProfile={onOpenDesignerProfile}
        onToggleFollow={onToggleFollow}
        isFollowing={followedDesigners ? followedDesigners.includes(item.designer) : false}
      />
    ))}
  </View>
));

const TwoRowHorizontalGrid = React.memo(({ items, onPress, onToggleLike, onOpenDesignerProfile, onToggleFollow, followedDesigners }) => {
  if (items.length === 0) {
    return (
      <View style={styles.emptyTabContainer}>
        <Text style={styles.emptySearchText}>No portfolios found in this section.</Text>
      </View>
    );
  }

  const columns = [];
  for (let i = 0; i < items.length; i += 4) {
    const block = items.slice(i, i + 4);
    const col1 = [];
    if (block[0]) col1.push(block[0]);
    if (block[2]) col1.push(block[2]);
    columns.push(col1);

    if (block[1]) {
      const col2 = [];
      col2.push(block[1]);
      if (block[3]) col2.push(block[3]);
      columns.push(col2);
    }
  }

  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 12 }}>
      <View style={styles.twoRowContainer}>
        {columns.map((col, colIdx) => (
          <View key={colIdx} style={styles.twoRowColumn}>
            {col.map((item) => (
              <ProjectCard
                key={item.id}
                item={item}
                onPress={onPress}
                onToggleLike={onToggleLike}
                onOpenDesignerProfile={onOpenDesignerProfile}
                onToggleFollow={onToggleFollow}
                isFollowing={followedDesigners ? followedDesigners.includes(item.designer) : false}
                customWidth={RESPONSIVE_PROFILE_CARD_WIDTH}
                hideBrief={true}
                isTwoRowCard={true}
              />
            ))}
          </View>
        ))}
      </View>
    </ScrollView>
  );
});


// Helper to upload image URIs to Supabase Storage
const uploadImageToSupabase = async (uri, path) => {
  if (!uri || !uri.startsWith('file://') && !uri.startsWith('content://')) {
    return uri; // Already a remote web URL
  }
  try {
    const response = await fetch(uri);
    const blob = await response.blob();
    const fileExt = uri.split('.').pop() || 'jpg';
    const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
    const filePath = `${path}/${fileName}`;

    const { data, error } = await supabase.storage
      .from('portfolio-media')
      .upload(filePath, blob, {
        contentType: `image/${fileExt}`,
        upsert: true
      });

    if (error) {
      console.warn('Supabase storage upload error:', error);
      return uri; // Fallback to local URI
    }

    const { data: publicUrlData } = supabase.storage
      .from('portfolio-media')
      .getPublicUrl(filePath);

    return publicUrlData.publicUrl || uri;
  } catch (err) {
    console.warn('Image upload exception:', err);
    return uri;
  }
};

export default function App() {
  const [projects, setProjects] = useState(INITIAL_PROJECTS);
  const [followedDesigners, setFollowedDesigners] = useState(['Iqbal Aprianda Putra', 'Maya Lin', 'Alex Rivera', 'Elena Rostova']);
  const [hideLikedPortfolios, setHideLikedPortfolios] = useState(false);
  
  const [userProfile, setUserProfile] = useState({
    name: 'Iqbal Aprianda Putra',
    role: 'UI/UX & Web Content Designer',
    location: 'South Jakarta, Jakarta, Indonesia',
    bio: 'Specializing in design systems, mobile apps, and interactive Figma prototypes.',
    email: 'iputra07@gmail.com',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
    links: [
      'https://www.figma.com/@iqbalaprianda',
      'https://dribbble.com',
      'https://linkedin.com'
    ]
  });

  const [notificationsList, setNotificationsList] = useState(INITIAL_NOTIFICATIONS);
  const [unreadNotifications, setUnreadNotifications] = useState(true);
  const [notificationModalVisible, setNotificationModalVisible] = useState(false);

  const [hydrated, setHydrated] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const [externalLinkModalVisible, setExternalLinkModalVisible] = useState(false);
  const [targetExternalUrl, setTargetExternalUrl] = useState('');

  const [accountSettingsModalVisible, setAccountSettingsModalVisible] = useState(false);
  const [accountSaveSuccessModalVisible, setAccountSaveSuccessModalVisible] = useState(false);

  const [editName, setEditName] = useState(userProfile.name);
  const [editRole, setEditRole] = useState(userProfile.role);
  const [editLocation, setEditLocation] = useState(userProfile.location);
  const [editBio, setEditBio] = useState(userProfile.bio);
  const [editEmail, setEditEmail] = useState(userProfile.email);
  const [editAvatar, setEditAvatar] = useState(userProfile.avatar);
  const [editLinks, setEditLinks] = useState(userProfile.links);

  // Settings Secondary Modals
  const [aboutModalVisible, setAboutModalVisible] = useState(false);
  const [privacyModalVisible, setPrivacyModalVisible] = useState(false);

  // Feedback & Support Modal
  const [feedbackModalVisible, setFeedbackModalVisible] = useState(false);
  const [feedbackEmail, setFeedbackEmail] = useState(userProfile.email);
  const [feedbackMessage, setFeedbackMessage] = useState('');
  const [feedbackNotifyEmail, setFeedbackNotifyEmail] = useState(true);
  const [feedbackSuccessModalVisible, setFeedbackSuccessModalVisible] = useState(false);

  // Donate Modal
  const [donateModalVisible, setDonateModalVisible] = useState(false);
  const [donateSuccessModalVisible, setDonateSuccessModalVisible] = useState(false);

  const [selectedFollowedDesigner, setSelectedFollowedDesigner] = useState(null);

  const [activeProject, setActiveProject] = useState(null);
  const [selectedDesigner, setSelectedDesigner] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [addModalVisible, setAddModalVisible] = useState(false);
  const [editingProjectId, setEditingProjectId] = useState(null);

  const [deleteConfirmModalVisible, setDeleteConfirmModalVisible] = useState(false);
  const [projectToDelete, setProjectToDelete] = useState(null);

  const [designerModalVisible, setDesignerModalVisible] = useState(false);
  const [designerProfileTab, setDesignerProfileTab] = useState('myWork');

  const [allCategoriesModalVisible, setAllCategoriesModalVisible] = useState(false);
  const [settingsModalVisible, setSettingsModalVisible] = useState(false);

  const [userListModalVisible, setUserListModalVisible] = useState(false);
  const [userListTitle, setUserListTitle] = useState('');
  const [userListItems, setUserListItems] = useState([]);

  const [activeTab, setActiveTab] = useState('case');
  const [loadingWebView, setLoadingWebView] = useState(true);

  const mainScrollViewRef = useRef(null);
  const [showBackToTop, setShowBackToTop] = useState(false);

  const modalScrollViewRef = useRef(null);
  const [showModalBackToTop, setShowModalBackToTop] = useState(false);

  const fadeAnim = useRef(new Animated.Value(1)).current;

  const [bottomNav, setBottomNav] = useState('forYou');
  const lastTabTapRef = useRef({ tab: 'forYou', time: 0 });

  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');

  const [profileTab, setProfileTab] = useState('myWork');

  const [formStep, setFormStep] = useState(1);
  const [fTitle, setFTitle] = useState('');
  const [fDesigner, setFDesigner] = useState('Iqbal Aprianda Putra');
  
  const [fCategories, setFCategories] = useState(['Mobile App']);
  const [categorySearchQuery, setCategorySearchQuery] = useState('');
  const [isCategorySearchActive, setIsCategorySearchActive] = useState(false);
  const [masterCategoriesList, setMasterCategoriesList] = useState(ALL_UIUX_CATEGORIES_MASTER);

  const [fBrief, setFBrief] = useState('');
  const [fFigmaProto, setFFigmaProto] = useState('');
  const [fDesktopProto, setFDesktopProto] = useState('');
  const [fFigmaFile, setFFigmaFile] = useState('');
  const [fFigmaProfile, setFFigmaProfile] = useState('');
  const [step2Skipped, setStep2Skipped] = useState(false);
  const [fCover, setFCover] = useState('');
  
  const [fShowcaseImages, setFShowcaseImages] = useState(['', '']);
  const [fVideoLinks, setFVideoLinks] = useState(['']);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    (async () => {
      try {
        // Try fetching online portfolios from Supabase
        const { data: onlinePortfolios, error } = await supabase
          .from('portfolios')
          .select('*')
          .order('created_at', { ascending: false });

        if (!error && onlinePortfolios && onlinePortfolios.length > 0) {
          const mapped = onlinePortfolios.map((p) => ({
            id: p.id,
            title: p.title,
            designer: p.user_name || 'Iqbal Aprianda Putra',
            designerAvatar: p.user_avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
            category: p.categories && p.categories[0] ? p.categories[0] : 'Mobile App',
            categories: p.categories || ['Mobile App'],
            liked: false,
            likesCount: p.likes_count || 1,
            visitsCount: p.visits_count || 120,
            figmaProfile: p.figma_profile || '',
            figmaProto: p.figma_proto || '',
            desktopProto: p.desktop_proto || '',
            figmaFile: p.figma_file || '',
            brief: p.brief || '',
            cover: p.cover_url || '',
            images: [p.cover_url || ''],
            videoLinks: [],
            caseStudy: `1. Overview & Project Goals\n\n${p.brief}`
          }));
          setProjects(mapped);
        } else {
          const savedProjects = await AsyncStorage.getItem(STORAGE_KEY);
          if (savedProjects) setProjects(JSON.parse(savedProjects));
        }

        const savedFollowed = await AsyncStorage.getItem(FOLLOWED_KEY);
        if (savedFollowed) setFollowedDesigners(JSON.parse(savedFollowed));

        const savedHideLiked = await AsyncStorage.getItem(HIDE_LIKED_KEY);
        if (savedHideLiked !== null) setHideLikedPortfolios(JSON.parse(savedHideLiked));

        const savedProfile = await AsyncStorage.getItem(USER_PROFILE_KEY);
        if (savedProfile) {
          const parsed = JSON.parse(savedProfile);
          setUserProfile(parsed);
          setEditName(parsed.name);
          setEditRole(parsed.role);
          setEditLocation(parsed.location || 'South Jakarta, Jakarta, Indonesia');
          setEditBio(parsed.bio);
          setEditEmail(parsed.email);
          setEditAvatar(parsed.avatar);
          setEditLinks(parsed.links || []);
          setFeedbackEmail(parsed.email);
        }
      } catch (e) {
        console.warn('Failed to load storage', e);
      } finally {
        setHydrated(true);
      }
    })();
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(projects)).catch((e) => console.warn('Save error', e));
  }, [projects, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    AsyncStorage.setItem(FOLLOWED_KEY, JSON.stringify(followedDesigners)).catch((e) => console.warn('Save error', e));
  }, [followedDesigners, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    AsyncStorage.setItem(HIDE_LIKED_KEY, JSON.stringify(hideLikedPortfolios)).catch((e) => console.warn('Save error', e));
  }, [hideLikedPortfolios, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    AsyncStorage.setItem(USER_PROFILE_KEY, JSON.stringify(userProfile)).catch((e) => console.warn('Save error', e));
  }, [userProfile, hydrated]);

  const openExternalLinkWithWarning = (url) => {
    if (!url) return;
    setTargetExternalUrl(url);
    setExternalLinkModalVisible(true);
  };

  const confirmProceedToExternalLink = () => {
    if (targetExternalUrl) {
      Linking.openURL(targetExternalUrl).catch((err) => console.warn("Failed to open link", err));
    }
    setExternalLinkModalVisible(false);
  };

  const handleRefresh = () => {
    setRefreshing(true);
    setTimeout(() => {
      setRefreshing(false);
    }, 1000);
  };

  const handleScroll = (event) => {
    const offsetY = event.nativeEvent.contentOffset.y;
    if (offsetY > 220) {
      if (!showBackToTop) setShowBackToTop(true);
    } else {
      if (showBackToTop) setShowBackToTop(false);
    }
  };

  const scrollToTop = () => {
    mainScrollViewRef.current?.scrollTo({ y: 0, animated: true });
  };

  const handleModalScroll = (event) => {
    const offsetY = event.nativeEvent.contentOffset.y;
    if (offsetY > 220) {
      if (!showModalBackToTop) setShowModalBackToTop(true);
    } else {
      if (showModalBackToTop) setShowModalBackToTop(false);
    }
  };

  const scrollModalToTop = () => {
    modalScrollViewRef.current?.scrollTo({ y: 0, animated: true });
  };

  const handleNavChange = (newNav) => {
    const now = Date.now();
    const isDoubleTap = lastTabTapRef.current.tab === newNav && (now - lastTabTapRef.current.time < 350);
    lastTabTapRef.current = { tab: newNav, time: now };

    if (newNav === bottomNav) {
      if (newNav === 'forYou') {
        setCategoryFilter('all');
      } else if (newNav === 'followed') {
        setSelectedFollowedDesigner(null);
      } else if (newNav === 'search') {
        setSearchQuery('');
      } else if (newNav === 'profile') {
        setProfileTab('myWork');
      }
      scrollToTop();
      return;
    }

    Animated.sequence([
      Animated.timing(fadeAnim, { toValue: 0.2, duration: 120, useNativeDriver: true }),
      Animated.timing(fadeAnim, { toValue: 1, duration: 220, useNativeDriver: true })
    ]).start();
    setBottomNav(newNav);
    setShowBackToTop(false);
  };

  const toggleLike = (id) => {
    setProjects((prev) =>
      prev.map((p) => {
        if (p.id === id) {
          const newLiked = !p.liked;
          const newCount = newLiked ? (p.likesCount || 0) + 1 : Math.max(0, (p.likesCount || 1) - 1);
          return { ...p, liked: newLiked, likesCount: newCount };
        }
        return p;
      })
    );
    if (activeProject && activeProject.id === id) {
      const newLiked = !activeProject.liked;
      const newCount = newLiked ? (activeProject.likesCount || 0) + 1 : Math.max(0, (activeProject.likesCount || 1) - 1);
      setActiveProject({ ...activeProject, liked: newLiked, likesCount: newCount });
    }
  };

  const toggleFollowDesigner = (designerName) => {
    if (followedDesigners.includes(designerName)) {
      setFollowedDesigners(followedDesigners.filter((name) => name !== designerName));
      if (selectedFollowedDesigner === designerName) {
        setSelectedFollowedDesigner(null);
      }
    } else {
      setFollowedDesigners([...followedDesigners, designerName]);
    }
  };

  const handleShareDesigner = (designer) => {
    const shareUrl = designer.figma || `https://portfolio.app/designer/${encodeURIComponent(designer.name)}`;
    Alert.alert(
      'Share Designer Profile',
      `Profile Link: ${shareUrl}`,
      [
        { text: 'Copy Link', onPress: () => Alert.alert('Copied!', 'Designer profile link copied to clipboard.') },
        { text: 'Cancel', style: 'cancel' }
      ]
    );
  };

  const handleOpenAccountSettingsModal = () => {
    setEditName(userProfile.name);
    setEditRole(userProfile.role);
    setEditLocation(userProfile.location || 'South Jakarta, Jakarta, Indonesia');
    setEditBio(userProfile.bio);
    setEditEmail(userProfile.email);
    setEditAvatar(userProfile.avatar);
    setEditLinks(userProfile.links || []);
    setAccountSettingsModalVisible(true);
  };

  const handleSaveAccountSettings = () => {
    const validLinks = editLinks.filter((l) => l.trim() !== '');
    const updated = {
      ...userProfile,
      name: editName.trim() || 'Iqbal Aprianda Putra',
      role: editRole.trim() || 'UI/UX & Web Content Designer',
      location: editLocation.trim() || 'South Jakarta, Jakarta, Indonesia',
      bio: editBio.trim() || 'Specializing in design systems, mobile apps, and interactive Figma prototypes.',
      email: editEmail.trim() || 'iputra07@gmail.com',
      avatar: editAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
      links: validLinks
    };
    setUserProfile(updated);
    setAccountSettingsModalVisible(false);
    setAccountSaveSuccessModalVisible(true);
  };

  const handleSubmitFeedback = () => {
    if (!feedbackMessage.trim()) {
      Alert.alert('Message Required', 'Please enter your feedback message or issue description.');
      return;
    }
    setFeedbackModalVisible(false);
    setFeedbackMessage('');
    setFeedbackSuccessModalVisible(true);
  };

  const handleDonateConfirm = () => {
    setDonateModalVisible(false);
    setDonateSuccessModalVisible(true);
  };

  const pickAvatarImage = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert('Permission Denied', 'Media library access is required to pick a profile photo.');
      return;
    }

    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8
    });

    if (!result.canceled && result.assets && result.assets.length > 0) {
      setEditAvatar(result.assets[0].uri);
    }
  };

  const handleAddAccountLink = () => {
    if (editLinks.length >= 5) {
      Alert.alert('Maximum Links Reached', 'You can add up to 5 profile links max.');
      return;
    }
    setEditLinks([...editLinks, '']);
  };

  const handleRemoveAccountLink = (index) => {
    const updated = editLinks.filter((_, i) => i !== index);
    setEditLinks(updated);
  };

  const handleLinkTextChange = (text, index) => {
    const updated = [...editLinks];
    updated[index] = text;
    setEditLinks(updated);
  };

  const openFollowersModal = (designer) => {
    setUserListTitle(`Followers of ${designer.name}`);
    setUserListItems(POPULAR_DESIGNERS.slice(0, 6));
    setUserListModalVisible(true);
  };

  const openFollowingModal = (designer) => {
    setUserListTitle(`${designer.name} is Following`);
    setUserListItems(POPULAR_DESIGNERS.slice(2, 8));
    setUserListModalVisible(true);
  };

  const openProjectModal = (proj) => {
    const newVisits = (proj.visitsCount || 100) + 1;
    const updatedProj = { ...proj, visitsCount: newVisits };
    
    setProjects((prev) =>
      prev.map((p) => (p.id === proj.id ? updatedProj : p))
    );
    setActiveProject(updatedProj);
    setShowModalBackToTop(false);

    if (proj.caseStudy || proj.brief || proj.images) {
      setActiveTab('case');
    } else if (proj.figmaProto) {
      setActiveTab('mobile');
    } else if (proj.desktopProto) {
      setActiveTab('desktop');
    } else {
      setActiveTab('case');
    }
    setModalVisible(true);
  };

  const openDesignerProfileByName = (designerName) => {
    const found = POPULAR_DESIGNERS.find(
      (d) => d.name.toLowerCase() === designerName.toLowerCase()
    );
    setDesignerProfileTab('myWork');
    if (found) {
      setModalVisible(false);
      setSelectedDesigner(found);
      setDesignerModalVisible(true);
    } else {
      setModalVisible(false);
      setSelectedDesigner({
        id: 'user_self',
        name: userProfile.name,
        role: userProfile.role,
        location: userProfile.location,
        avatar: userProfile.avatar,
        figma: 'https://www.figma.com/@iqbalaprianda',
        bio: userProfile.bio,
        followersCount: 1420,
        followingCount: 280,
        links: userProfile.links
      });
      setDesignerModalVisible(true);
    }
  };

  const openDesignerModal = (designer) => {
    setDesignerProfileTab('myWork');
    setSelectedDesigner(designer);
    setDesignerModalVisible(true);
  };

  const promptDeletePortfolio = (proj) => {
    setProjectToDelete(proj);
    setDeleteConfirmModalVisible(true);
  };

  const confirmDeletePortfolio = () => {
    if (projectToDelete) {
      setProjects((prev) => prev.filter((p) => p.id !== projectToDelete.id));
      setDeleteConfirmModalVisible(false);
      setModalVisible(false);
      setProjectToDelete(null);
      Alert.alert('Deleted', 'Portfolio package removed successfully.');
    }
  };

  const getDesignerRole = (designerName) => {
    const found = POPULAR_DESIGNERS.find(
      (d) => d.name.toLowerCase() === designerName.toLowerCase()
    );
    return found ? found.role : userProfile.role;
  };

  const toggleCategorySelection = (cat) => {
    if (fCategories.includes(cat)) {
      setFCategories(fCategories.filter((c) => c !== cat));
    } else {
      if (fCategories.length >= 5) {
        Alert.alert('Category Limit Reached', 'You can select up to 5 categories max per portfolio package.');
        return;
      }
      setFCategories([...fCategories, cat]);
    }
  };

  const handleAddCustomCategory = () => {
    const trimmed = categorySearchQuery.trim();
    if (!trimmed) return;
    if (fCategories.length >= 5) {
      Alert.alert('Category Limit Reached', 'You can select up to 5 categories max per portfolio package.');
      return;
    }
    if (!masterCategoriesList.includes(trimmed)) {
      setMasterCategoriesList([...masterCategoriesList, trimmed].sort());
    }
    if (!fCategories.includes(trimmed)) {
      setFCategories([...fCategories, trimmed]);
    }
    setCategorySearchQuery('');
  };

  const openEditWizard = (proj) => {
    setEditingProjectId(proj.id);
    setFTitle(proj.title || '');
    setFDesigner(proj.designer || userProfile.name);
    setFCategories(Array.isArray(proj.category) ? proj.category : [proj.category || 'Mobile App']);
    setFBrief(proj.brief || '');
    setFFigmaProto(proj.figmaProto || '');
    setFDesktopProto(proj.desktopProto || '');
    setFFigmaFile(proj.figmaFile || '');
    setFFigmaProfile(proj.figmaProfile || '');
    setFCover(proj.cover || '');
    setFShowcaseImages(proj.images && proj.images.length >= 2 ? proj.images : [proj.cover || '', '']);
    setFVideoLinks(proj.videoLinks && proj.videoLinks.length > 0 ? proj.videoLinks : ['']);
    setFormStep(1);
    setModalVisible(false);
    setAddModalVisible(true);
  };

  const handleAddShowcaseImage = () => {
    if (fShowcaseImages.length >= 10) {
      Alert.alert('Maximum Limit Reached', 'You can upload up to 10 showcase images.');
      return;
    }
    setFShowcaseImages([...fShowcaseImages, '']);
  };

  const handleRemoveShowcaseImage = (index) => {
    if (fShowcaseImages.length <= 2) {
      Alert.alert('Minimum Required', 'At least 2 showcase images are required.');
      return;
    }
    const updated = fShowcaseImages.filter((_, i) => i !== index);
    setFShowcaseImages(updated);
  };

  const pickShowcaseImageAtIndex = async (index) => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert('Permission Denied', 'Media library access is required to upload local photos.');
      return;
    }

    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8
    });

    if (!result.canceled && result.assets && result.assets.length > 0) {
      const uri = result.assets[0].uri;
      const updated = [...fShowcaseImages];
      updated[index] = uri;
      setFShowcaseImages(updated);
      setErrors({ ...errors, showcaseImages: null });
    }
  };

  const pickCoverImage = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert('Permission Denied', 'Media library access is required to upload local photos.');
      return;
    }

    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [16, 9],
      quality: 0.8
    });

    if (!result.canceled && result.assets && result.assets.length > 0) {
      setFCover(result.assets[0].uri);
      setErrors({ ...errors, fCover: null });
    }
  };

  const handleAddMoreVideo = () => {
    setFVideoLinks([...fVideoLinks, '']);
  };

  const handleRemoveVideoLink = (index) => {
    if (fVideoLinks.length <= 1) return;
    const updated = fVideoLinks.filter((_, i) => i !== index);
    setFVideoLinks(updated);
  };

  const handleVideoUrlChange = (text, index) => {
    const updated = [...fVideoLinks];
    updated[index] = text;
    setFVideoLinks(updated);
  };

  const handleNextFromStep1 = () => {
    let errs = {};
    if (!fTitle.trim()) errs.fTitle = 'Please enter a portfolio title';
    if (!fBrief.trim()) errs.fBrief = 'Please enter a short brief or summary';
    if (fCategories.length === 0) errs.fCategories = 'Please select at least 1 category.';

    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }
    setErrors({});
    setFormStep(2);
  };

  const handleNextFromStep2 = (skip = false) => {
    setStep2Skipped(skip);
    setFormStep(3);
  };

  const handleNextFromStep3 = () => {
    let errs = {};
    if (!fCover.trim()) errs.fCover = 'Please select a cover thumbnail photo from your phone or PC';
    
    const validShowcase = fShowcaseImages.filter((img) => img.trim() !== '');
    if (validShowcase.length < 2) {
      errs.showcaseImages = 'Please pick at least 2 showcase images.';
    }

    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }
    setErrors({});
    setFormStep(4);
  };

    const handleFinalPostPackage = async () => {
    const validVideos = fVideoLinks.filter((v) => v.trim() !== '');
    const validShowcaseImgs = fShowcaseImages.filter((img) => img.trim() !== '');

    if (editingProjectId) {
      setProjects((prev) =>
        prev.map((p) =>
          p.id === editingProjectId
            ? {
                ...p,
                title: fTitle,
                designer: fDesigner || userProfile.name,
                category: fCategories[0] || 'Mobile App',
                categories: fCategories,
                figmaProfile: fFigmaProfile || 'https://www.figma.com/@iqbalaprianda',
                figmaProto: fFigmaProto,
                desktopProto: fDesktopProto,
                figmaFile: fFigmaFile,
                brief: fBrief,
                cover: fCover,
                images: validShowcaseImgs.length > 0 ? validShowcaseImgs : [fCover],
                videoLinks: validVideos
              }
            : p
        )
      );
      Alert.alert('Updated', 'Portfolio package updated successfully!');
    } else {
      // 1. Upload Cover Image to Supabase Storage
      let finalCoverUrl = fCover;
      if (fCover && (fCover.startsWith('file://') || fCover.startsWith('content://') || fCover.startsWith('ph://'))) {
        finalCoverUrl = await uploadImageToSupabase(fCover, 'covers');
      }

      // 2. Upload Showcase Images to Supabase Storage
      const uploadedShowcase = [];
      for (const img of validShowcaseImgs) {
        if (img.startsWith('file://') || img.startsWith('content://') || img.startsWith('ph://')) {
          const up = await uploadImageToSupabase(img, 'showcase');
          uploadedShowcase.push(up);
        } else {
          uploadedShowcase.push(img);
        }
      }

      const finalImages = uploadedShowcase.length > 0 ? uploadedShowcase : [finalCoverUrl];

      // 3. Insert into Supabase 'portfolios' table
      let insertedId = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      try {
        const { data: dbData, error: dbError } = await supabase
          .from('portfolios')
          .insert([{
            user_name: fDesigner || userProfile.name,
            user_avatar: userProfile.avatar,
            title: fTitle,
            brief: fBrief,
            cover_url: finalCoverUrl,
            figma_proto: fFigmaProto,
            desktop_proto: fDesktopProto,
            figma_file: fFigmaFile,
            figma_profile: fFigmaProfile,
            categories: fCategories,
            likes_count: 1,
            visits_count: 1
          }])
          .select();

        if (dbError) {
          console.warn('Supabase DB Insert Error:', dbError);
          Alert.alert('Notice', `Saved locally. Supabase error: ${dbError.message}`);
        } else if (dbData && dbData.length > 0) {
          insertedId = dbData[0].id;

          // Insert showcase images into portfolio_images table
          if (finalImages.length > 0) {
            const imgRows = finalImages.map(url => ({
              portfolio_id: insertedId,
              image_url: url
            }));
            await supabase.from('portfolio_images').insert(imgRows);
          }
        }
      } catch (err) {
        console.warn('Supabase Exception:', err);
      }

      const newProject = {
        id: insertedId,
        title: fTitle,
        designer: fDesigner || userProfile.name,
        designerAvatar: userProfile.avatar,
        category: fCategories[0] || 'Mobile App',
        categories: fCategories,
        liked: false,
        likesCount: 1,
        visitsCount: 1,
        figmaProfile: fFigmaProfile || 'https://www.figma.com/@iqbalaprianda',
        figmaProto: fFigmaProto,
        desktopProto: fDesktopProto,
        figmaFile: fFigmaFile,
        brief: fBrief,
        cover: finalCoverUrl,
        images: finalImages,
        videoLinks: validVideos,
        caseStudy: `1. Overview & Project Goals\n\n${fBrief}\n\n2. Design Execution\nCustom multi-step portfolio package.`
      };

      setProjects([newProject, ...projects]);
      Alert.alert('Success!', 'Your portfolio package has been posted online to Supabase!');
    }

    setAddModalVisible(false);
    resetFormWizard();
  };

  const resetFormWizard = () => {
    setEditingProjectId(null);
    setFormStep(1);
    setFTitle('');
    setFBrief('');
    setFCategories(['Mobile App']);
    setCategorySearchQuery('');
    setIsCategorySearchActive(false);
    setFFigmaProto('');
    setFDesktopProto('');
    setFFigmaFile('');
    setFFigmaProfile('');
    setFCover('');
    setFShowcaseImages(['', '']);
    setFVideoLinks(['']);
    setErrors({});
    setStep2Skipped(false);
  };

  const getFigmaEmbedUrl = (url) => {
    if (!url) return '';
    if (!url.includes('figma.com/embed')) {
      return `https://www.figma.com/embed?embed_host=share&url=${encodeURIComponent(url)}`;
    }
    return url;
  };

  const handleWebViewNavigation = (request) => {
    const { url } = request;
    if (!url) return true;

    const isFigmaInternal =
      url.includes('figma.com') ||
      url.includes('figmame.com') ||
      url.startsWith('about:blank') ||
      url.startsWith('blob:') ||
      url.startsWith('data:');

    if (isFigmaInternal) {
      return true;
    } else {
      openExternalLinkWithWarning(url);
      return false;
    }
  };

  const forYouCategoryFilteredProjects = useMemo(() => {
    return projects.filter((p) => {
      if (categoryFilter !== 'all') {
        if (Array.isArray(p.categories)) {
          return p.categories.includes(categoryFilter);
        }
        return p.category === categoryFilter;
      }
      return true;
    });
  }, [projects, categoryFilter]);

  const followedProjects = useMemo(() => {
    return projects.filter((p) => {
      if (selectedFollowedDesigner) {
        return p.designer === selectedFollowedDesigner;
      }
      return followedDesigners.includes(p.designer);
    });
  }, [projects, selectedFollowedDesigner, followedDesigners]);

  const followedDesignersObjects = useMemo(() => {
    return POPULAR_DESIGNERS.filter((d) => followedDesigners.includes(d.name));
  }, [followedDesigners]);

  const searchedProjects = useMemo(() => {
    if (searchQuery.trim() === '') return [];
    const q = searchQuery.toLowerCase();
    return projects.filter((p) =>
      p.title.toLowerCase().includes(q) ||
      p.designer.toLowerCase().includes(q) ||
      p.brief.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q)
    );
  }, [projects, searchQuery]);

  const searchedDesigners = useMemo(() => {
    if (searchQuery.trim() === '') return POPULAR_DESIGNERS;
    const q = searchQuery.toLowerCase();
    return POPULAR_DESIGNERS.filter((d) =>
      d.name.toLowerCase().includes(q) ||
      d.role.toLowerCase().includes(q) ||
      d.location.toLowerCase().includes(q)
    );
  }, [searchQuery]);

  const myUploadedProjects = useMemo(() => {
    const nameLower = userProfile.name.toLowerCase();
    return projects.filter((p) =>
      p.designer.toLowerCase().includes('iqbal') ||
      p.designer.toLowerCase().includes(nameLower)
    );
  }, [projects, userProfile.name]);

  const myLikedProjects = useMemo(() => {
    return projects.filter((p) => p.liked === true);
  }, [projects]);

  const filteredCategoriesForWizard = useMemo(() => {
    if (!categorySearchQuery.trim()) return masterCategoriesList;
    const q = categorySearchQuery.toLowerCase();
    return masterCategoriesList.filter((cat) => cat.toLowerCase().includes(q));
  }, [masterCategoriesList, categorySearchQuery]);

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0B0F17" translucent={false} />

      {/* Header with App Name DECENT Text Only (Removed Mockup Icon) & Switched Header Icons */}
      <View style={styles.header}>
        <View style={styles.logoRow}>
          <Text style={styles.logoText}>DECENT</Text>
          <View style={styles.versionBadge}>
            <Text style={styles.versionText}>v5.2.6 Native</Text>
          </View>
        </View>

        <View style={styles.headerRightActionsRow}>
          <TouchableOpacity
            style={styles.headerIconBtnWithBadge}
            onPress={() => {
              setUnreadNotifications(false);
              setNotificationModalVisible(true);
            }}
          >
            <BellSVG />
            {unreadNotifications && <View style={styles.unreadRedBadgeDot} />}
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.headerIconBtn}
            onPress={() => setSettingsModalVisible(true)}
          >
            <CogWheelSVG />
          </TouchableOpacity>
        </View>
      </View>

      <Animated.View style={[styles.mainViewContainer, { opacity: fadeAnim }]}>
        <ScrollView
          ref={mainScrollViewRef}
          style={styles.scrollView}
          contentContainerStyle={styles.scrollContent}
          onScroll={handleScroll}
          scrollEventThrottle={16}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor="#8B5CF6" colors={['#8B5CF6']} />
          }
        >

          {/* TAB PAGE 1: FOR YOU Feed */}
          {bottomNav === 'forYou' && (
            <View>
              <View style={styles.topCategoryBarWrapper}>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.topCategoryScrollView}>
                  <TouchableOpacity
                    style={[styles.topCategoryChip, categoryFilter === 'all' && styles.topCategoryChipActive]}
                    onPress={() => setCategoryFilter('all')}
                  >
                    <Text style={[styles.topCategoryText, categoryFilter === 'all' && styles.topCategoryTextActive]}>
                      All Work
                    </Text>
                  </TouchableOpacity>

                  {['Mobile App', 'Web Design', 'Design System', 'FinTech', 'Healthcare', 'E-Commerce', 'SaaS'].map((cat) => (
                    <TouchableOpacity
                      key={cat}
                      style={[styles.topCategoryChip, categoryFilter === cat && styles.topCategoryChipActive]}
                      onPress={() => setCategoryFilter(cat)}
                    >
                      <Text style={[styles.topCategoryText, categoryFilter === cat && styles.topCategoryTextActive]}>
                        {cat}
                      </Text>
                    </TouchableOpacity>
                  ))}

                  <TouchableOpacity
                    style={styles.grid2x2CategoryBtn}
                    activeOpacity={0.8}
                    onPress={() => setAllCategoriesModalVisible(true)}
                  >
                    <Grid2x2SVG />
                  </TouchableOpacity>
                </ScrollView>
              </View>

              <ProjectGrid
                items={forYouCategoryFilteredProjects}
                onPress={openProjectModal}
                onToggleLike={toggleLike}
                onOpenDesignerProfile={openDesignerProfileByName}
                onToggleFollow={toggleFollowDesigner}
                followedDesigners={followedDesigners}
              />
            </View>
          )}

          {/* TAB PAGE 2: FOLLOWING Feed (Renamed from Followed) */}
          {bottomNav === 'followed' && (
            <View>
              <View style={styles.pageHeaderBox}>
                <Text style={styles.pageHeaderTitle}>Following Designers Feed</Text>
                <Text style={styles.pageHeaderSubtitle}>
                  {selectedFollowedDesigner
                    ? `Showing releases by ${selectedFollowedDesigner}`
                    : `Latest portfolio releases from designers you follow (${followedDesigners.length}).`}
                </Text>
              </View>

              {followedDesignersObjects.length > 0 && (
                <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.storiesBarScroll}>
                  {followedDesignersObjects.map((des) => {
                    const isSelected = selectedFollowedDesigner === des.name;
                    return (
                      <TouchableOpacity
                        key={des.id}
                        style={styles.storyCircleWrapper}
                        onPress={() => {
                          if (selectedFollowedDesigner === des.name) {
                            setSelectedFollowedDesigner(null);
                          } else {
                            setSelectedFollowedDesigner(des.name);
                          }
                        }}
                      >
                        <View style={[styles.storyRing, isSelected && styles.storyRingActive]}>
                          <Image source={{ uri: des.avatar }} style={styles.storyAvatar} />
                        </View>
                        <Text style={[styles.storyNameText, isSelected && styles.storyNameTextActive]} numberOfLines={1}>
                          {des.name.split(' ')[0]}
                        </Text>
                      </TouchableOpacity>
                    );
                  })}
                </ScrollView>
              )}

              {followedProjects.length > 0 ? (
                <ProjectGrid
                  items={followedProjects}
                  onPress={openProjectModal}
                  onToggleLike={toggleLike}
                  onOpenDesignerProfile={openDesignerProfileByName}
                  onToggleFollow={toggleFollowDesigner}
                  followedDesigners={followedDesigners}
                />
              ) : (
                <View style={styles.emptyFollowedBox}>
                  <Text style={styles.emptyFollowedTitle}>
                    {selectedFollowedDesigner ? `No Releases from ${selectedFollowedDesigner}` : 'No Posts from Following Designers'}
                  </Text>
                  <Text style={styles.emptyFollowedSub}>
                    {selectedFollowedDesigner
                      ? 'Tap their story circle again to clear filter and view all followed designers.'
                      : "You aren't following any designers with recent releases yet. Go to Search to discover and follow designers!"}
                  </Text>
                  <TouchableOpacity
                    style={styles.discoverDesignersBtn}
                    onPress={() => {
                      if (selectedFollowedDesigner) setSelectedFollowedDesigner(null);
                      else handleNavChange('search');
                    }}
                  >
                    <View style={styles.iconTextInlineRow}>
                      <Text style={styles.discoverBtnText}>
                        {selectedFollowedDesigner ? 'Clear Filter' : 'Discover Designers'}
                      </Text>
                      <ChevronRightSVG color="#FFFFFF" size={16} />
                    </View>
                  </TouchableOpacity>
                </View>
              )}
            </View>
          )}

          {/* TAB PAGE 3: SEARCH */}
          {bottomNav === 'search' && (
            <View>
              <View style={styles.searchContainer}>
                <TextInput
                  style={styles.searchInput}
                  placeholder="Search by project name, designer, or topic..."
                  placeholderTextColor="#94A3B8"
                  value={searchQuery}
                  onChangeText={setSearchQuery}
                  autoFocus={true}
                />
              </View>

              {searchQuery.trim() !== '' ? (
                <View>
                  <Text style={styles.sectionHeader}>SEARCH RESULTS ({searchedProjects.length})</Text>
                  {searchedProjects.length > 0 ? (
                    <ProjectGrid
                      items={searchedProjects}
                      onPress={openProjectModal}
                      onToggleLike={toggleLike}
                      onOpenDesignerProfile={openDesignerProfileByName}
                      onToggleFollow={toggleFollowDesigner}
                      followedDesigners={followedDesigners}
                    />
                  ) : (
                    <Text style={styles.emptySearchText}>No portfolio packages matched "{searchQuery}".</Text>
                  )}
                </View>
              ) : (
                <View>
                  <Text style={styles.sectionHeader}>POPULAR KEYWORDS</Text>
                  <View style={styles.keywordsRow}>
                    {POPULAR_KEYWORDS.map((kw) => (
                      <TouchableOpacity
                        key={kw}
                        style={styles.keywordChip}
                        onPress={() => setSearchQuery(kw)}
                      >
                        <View style={styles.iconTextInlineRow}>
                          <SearchChipSVG />
                          <Text style={styles.keywordText}>{kw}</Text>
                        </View>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>
              )}

              <Text style={[styles.sectionHeader, { marginTop: 28 }]}>
                DISCOVER DESIGNERS ({searchedDesigners.length})
              </Text>
              <View style={styles.designersList}>
                {searchedDesigners.map((des) => {
                  const isFollowing = followedDesigners.includes(des.name);
                  return (
                    <TouchableOpacity
                      key={des.id}
                      style={styles.designerItemCard}
                      onPress={() => openDesignerModal(des)}
                    >
                      <Image source={{ uri: des.avatar }} style={styles.designerListAvatar} />
                      <View style={styles.designerInfoCol}>
                        <Text style={styles.designerListName}>{des.name}</Text>
                        <Text style={styles.designerListRole}>{des.role}</Text>
                        <View style={styles.iconTextInlineRow}>
                          <LocationPinSVG />
                          <Text style={styles.designerListLoc}>{des.location}</Text>
                        </View>

                        <View style={styles.designerCardActionsRow}>
                          <TouchableOpacity
                            style={[styles.smallFollowBtn, isFollowing && styles.smallFollowBtnActive]}
                            onPress={() => toggleFollowDesigner(des.name)}
                          >
                            <Text style={[styles.smallFollowText, isFollowing && styles.smallFollowTextActive]}>
                              {isFollowing ? 'Following' : '+ Follow Back'}
                            </Text>
                          </TouchableOpacity>

                          <TouchableOpacity
                            style={styles.smallShareBtnIconOnly}
                            onPress={() => handleShareDesigner(des)}
                          >
                            <ShareIconSVG />
                          </TouchableOpacity>
                        </View>
                      </View>
                      <ChevronRightSVG color="#8B5CF6" size={20} />
                    </TouchableOpacity>
                  );
                })}
              </View>
            </View>
          )}

          {/* TAB PAGE 4: PROFILE */}
          {bottomNav === 'profile' && (
            <View>
              <View style={styles.profileCard}>
                <TouchableOpacity
                  style={styles.profileTopRightShareBtn}
                  onPress={() => handleShareDesigner({ name: userProfile.name, figma: 'https://www.figma.com/@iqbalaprianda' })}
                >
                  <ShareIconSVG />
                </TouchableOpacity>

                <Image
                  source={{ uri: userProfile.avatar }}
                  style={styles.profileLargeAvatar}
                />
                <Text style={styles.profileName}>{userProfile.name}</Text>
                <Text style={styles.profileRole}>{userProfile.role}</Text>
                
                <View style={[styles.iconTextInlineRow, { marginBottom: 8 }]}>
                  <LocationPinSVG />
                  <Text style={styles.profileLocText}>{userProfile.location}</Text>
                </View>

                <Text style={styles.profileBio}>{userProfile.bio}</Text>

                <View style={styles.statsRow}>
                  <TouchableOpacity
                    style={styles.statItem}
                    onPress={() => openFollowersModal({ name: userProfile.name })}
                  >
                    <Text style={styles.statNum}>1.4k</Text>
                    <Text style={styles.statLabel}>Followers</Text>
                  </TouchableOpacity>

                  <View style={styles.statDivider} />

                  <TouchableOpacity
                    style={styles.statItem}
                    onPress={() => openFollowingModal({ name: userProfile.name })}
                  >
                    <Text style={styles.statNum}>280</Text>
                    <Text style={styles.statLabel}>Following</Text>
                  </TouchableOpacity>
                </View>

                {userProfile.links && userProfile.links.length > 0 && (
                  <View style={styles.socialCircularLinksRow}>
                    {userProfile.links.map((linkUrl, idx) => (
                      <TouchableOpacity
                        key={idx}
                        style={styles.socialCircleBtn}
                        onPress={() => openExternalLinkWithWarning(linkUrl)}
                      >
                        {getSocialLogoSVG(linkUrl)}
                      </TouchableOpacity>
                    ))}
                  </View>
                )}
              </View>

              <View style={styles.profileTabsBar}>
                <TouchableOpacity
                  style={[styles.profileTabBtn, profileTab === 'myWork' && styles.profileTabBtnActive]}
                  onPress={() => setProfileTab('myWork')}
                >
                  <Text style={[styles.profileTabBtnText, profileTab === 'myWork' && styles.profileTabBtnTextActive]}>
                    My Portfolios ({myUploadedProjects.length})
                  </Text>
                </TouchableOpacity>

                {!hideLikedPortfolios && (
                  <TouchableOpacity
                    style={[styles.profileTabBtn, profileTab === 'likedWork' && styles.profileTabBtnActive]}
                    onPress={() => setProfileTab('likedWork')}
                  >
                    <Text style={[styles.profileTabBtnText, profileTab === 'likedWork' && styles.profileTabBtnTextActive]}>
                      Liked Portfolios ({myLikedProjects.length})
                    </Text>
                  </TouchableOpacity>
                )}
              </View>

              <TwoRowHorizontalGrid
                items={(profileTab === 'myWork' || hideLikedPortfolios) ? myUploadedProjects : myLikedProjects}
                onPress={openProjectModal}
                onToggleLike={toggleLike}
                onOpenDesignerProfile={openDesignerProfileByName}
                onToggleFollow={toggleFollowDesigner}
                followedDesigners={followedDesigners}
              />
            </View>
          )}

        </ScrollView>
      </Animated.View>

      {/* STICKY BACK TO TOP FLOATING BUTTON */}
      {showBackToTop && (
        <TouchableOpacity
          style={styles.stickyBackToTopBtn}
          activeOpacity={0.85}
          onPress={scrollToTop}
        >
          <ChevronUpSVG />
        </TouchableOpacity>
      )}

      {/* FLOATING ROUNDED RECTANGLE BOTTOM MENU BAR WITH FOLLOWING LABEL */}
      <View style={styles.floatingBottomBar}>
        <TouchableOpacity style={styles.uniformTabItem} onPress={() => handleNavChange('forYou')}>
          <ForYouSVG active={bottomNav === 'forYou'} />
          <Text style={[styles.menuLabel, bottomNav === 'forYou' && styles.menuLabelActive]}>For You</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.uniformTabItem} onPress={() => handleNavChange('followed')}>
          <FollowedTabSVG active={bottomNav === 'followed'} />
          <Text style={[styles.menuLabel, bottomNav === 'followed' && styles.menuLabelActive]}>Following</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.plusContainerBtn} activeOpacity={0.85} onPress={() => { resetFormWizard(); setAddModalVisible(true); }}>
          <PlusSVG />
        </TouchableOpacity>

        <TouchableOpacity style={styles.uniformTabItem} onPress={() => handleNavChange('search')}>
          <SearchSVG active={bottomNav === 'search'} />
          <Text style={[styles.menuLabel, bottomNav === 'search' && styles.menuLabelActive]}>Search</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.uniformTabItem} onPress={() => handleNavChange('profile')}>
          <ProfileSVG active={bottomNav === 'profile'} />
          <Text style={[styles.menuLabel, bottomNav === 'profile' && styles.menuLabelActive]}>Profile</Text>
        </TouchableOpacity>
      </View>

      {/* EXTERNAL LINK LEAVING WARNING CONFIRMATION MODAL */}
      <Modal
        animationType="fade"
        transparent={true}
        visible={externalLinkModalVisible}
        onRequestClose={() => setExternalLinkModalVisible(false)}
      >
        <View style={styles.overlayModalBg}>
          <View style={styles.customConfirmCard}>
            <View style={styles.confirmIconCircle}>
              <WarningTriangleSVG />
            </View>
            <Text style={styles.confirmTitle}>Leaving DECENT</Text>
            <Text style={styles.confirmSubText}>
              You are about to open an external website:
            </Text>

            <View style={styles.linkUrlBox}>
              <Text style={styles.linkUrlText} numberOfLines={2}>{targetExternalUrl}</Text>
            </View>

            <View style={styles.confirmActionsRow}>
              <TouchableOpacity
                style={styles.confirmCancelBtn}
                onPress={() => setExternalLinkModalVisible(false)}
              >
                <Text style={styles.confirmCancelText}>Cancel</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.confirmDeleteBtn}
                onPress={confirmProceedToExternalLink}
              >
                <View style={styles.iconTextInlineRow}>
                  <Text style={styles.confirmDeleteText}>Continue</Text>
                  <ChevronRightSVG color="#FFFFFF" size={16} />
                </View>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* NOTIFICATIONS POP-UP OVERLAY MODAL */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={notificationModalVisible}
        onRequestClose={() => setNotificationModalVisible(false)}
      >
        <View style={styles.overlayModalBg}>
          <SafeAreaView style={styles.overlayModalContainer}>
            <View style={styles.modalTopBar}>
              <Text style={styles.modalTopTitle}>Notifications</Text>
              <TouchableOpacity style={styles.closeBtn} onPress={() => setNotificationModalVisible(false)}>
                <Text style={styles.closeBtnText}>✕</Text>
              </TouchableOpacity>
            </View>

            <ScrollView contentContainerStyle={{ padding: 16, gap: 12 }}>
              {notificationsList.map((notif) => {
                const isFollowingUser = followedDesigners.includes(notif.user);
                return (
                  <View key={notif.id} style={styles.notificationCard}>
                    <Image source={{ uri: notif.avatar }} style={styles.notifAvatar} />
                    <View style={{ flex: 1, marginRight: 6 }}>
                      <Text style={styles.notifText}>
                        <Text style={styles.notifUserBold}>{notif.user}</Text> {notif.action}{' '}
                        {notif.target ? <Text style={styles.notifTargetBold}>"{notif.target}"</Text> : null}
                      </Text>
                      <Text style={styles.notifTimeText}>{notif.time}</Text>
                    </View>

                    {notif.type === 'follow' ? (
                      <TouchableOpacity
                        style={[styles.notifFollowBackBtn, isFollowingUser && styles.notifFollowBackBtnActive]}
                        onPress={() => toggleFollowDesigner(notif.user)}
                      >
                        <Text style={[styles.notifFollowBackText, isFollowingUser && styles.notifFollowBackTextActive]}>
                          {isFollowingUser ? 'Following' : '+ Follow Back'}
                        </Text>
                      </TouchableOpacity>
                    ) : (
                      <View style={styles.notifTypeIconBox}>
                        <HeartIconSVG liked={true} />
                      </View>
                    )}
                  </View>
                );
              })}
            </ScrollView>
          </SafeAreaView>
        </View>
      </Modal>

      {/* ACCOUNT SETTINGS SAVE SUCCESS CUSTOM POP-UP WITH "CONTINUE" BUTTON */}
      <Modal
        animationType="fade"
        transparent={true}
        visible={accountSaveSuccessModalVisible}
        onRequestClose={() => setAccountSaveSuccessModalVisible(false)}
      >
        <View style={styles.overlayModalBg}>
          <View style={styles.customConfirmCard}>
            <View style={styles.successIconCircle}>
              <CheckIconSVG />
            </View>
            <Text style={styles.confirmTitle}>Settings Saved</Text>
            <Text style={styles.confirmSubText}>
              Your account profile, location, and preferences have been updated successfully!
            </Text>
            <TouchableOpacity
              style={[styles.confirmDeleteBtn, { width: '100%', marginTop: 8 }]}
              onPress={() => setAccountSaveSuccessModalVisible(false)}
            >
              <Text style={styles.confirmDeleteText}>Continue</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* ACCOUNT SETTINGS EDIT MODAL WITH LOCATION FIELD */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={accountSettingsModalVisible}
        onRequestClose={() => setAccountSettingsModalVisible(false)}
      >
        <View style={styles.overlayModalBg}>
          <SafeAreaView style={styles.overlayModalContainer}>
            <View style={styles.modalTopBar}>
              <Text style={styles.modalTopTitle}>Account Settings</Text>
              <TouchableOpacity style={styles.closeBtn} onPress={() => setAccountSettingsModalVisible(false)}>
                <Text style={styles.closeBtnText}>✕</Text>
              </TouchableOpacity>
            </View>

            <ScrollView contentContainerStyle={styles.accountSettingsScrollContent}>
              <Text style={styles.formGroupLabel}>Profile Picture</Text>
              <TouchableOpacity style={styles.avatarEditPickerBtn} activeOpacity={0.85} onPress={pickAvatarImage}>
                <Image source={{ uri: editAvatar }} style={styles.avatarEditPreview} />
                <View style={styles.avatarEditOverlay}>
                  <CameraIconSVG />
                  <Text style={styles.avatarEditText}>Change Photo</Text>
                </View>
              </TouchableOpacity>

              <Text style={styles.formGroupLabel}>Full Name</Text>
              <View style={styles.inputWithClearRow}>
                <TextInput
                  style={[styles.formInput, { flex: 1 }]}
                  value={editName}
                  onChangeText={setEditName}
                  placeholder="Full Name"
                  placeholderTextColor="#94A3B8"
                />
                {editName.length > 0 && (
                  <TouchableOpacity style={styles.clearFieldBtn} onPress={() => setEditName('')}>
                    <ClearTextXSVG />
                  </TouchableOpacity>
                )}
              </View>

              <Text style={styles.formGroupLabel}>Specialties / Position</Text>
              <View style={styles.inputWithClearRow}>
                <TextInput
                  style={[styles.formInput, { flex: 1 }]}
                  value={editRole}
                  onChangeText={setEditRole}
                  placeholder="Specialties / Role"
                  placeholderTextColor="#94A3B8"
                />
                {editRole.length > 0 && (
                  <TouchableOpacity style={styles.clearFieldBtn} onPress={() => setEditRole('')}>
                    <ClearTextXSVG />
                  </TouchableOpacity>
                )}
              </View>

              {/* Added Location Field */}
              <Text style={styles.formGroupLabel}>Location / City</Text>
              <View style={styles.inputWithClearRow}>
                <TextInput
                  style={[styles.formInput, { flex: 1 }]}
                  value={editLocation}
                  onChangeText={setEditLocation}
                  placeholder="South Jakarta, Jakarta, Indonesia"
                  placeholderTextColor="#94A3B8"
                />
                {editLocation.length > 0 && (
                  <TouchableOpacity style={styles.clearFieldBtn} onPress={() => setEditLocation('')}>
                    <ClearTextXSVG />
                  </TouchableOpacity>
                )}
              </View>

              <Text style={styles.formGroupLabel}>Short Brief / Bio</Text>
              <TextInput
                style={[styles.formInput, { height: 74, textAlignVertical: 'top' }]}
                multiline
                value={editBio}
                onChangeText={setEditBio}
                placeholder="Short bio..."
                placeholderTextColor="#94A3B8"
              />

              <Text style={styles.formGroupLabel}>Email Address</Text>
              <View style={styles.inputWithClearRow}>
                <TextInput
                  style={[styles.formInput, { flex: 1 }]}
                  value={editEmail}
                  onChangeText={setEditEmail}
                  placeholder="Email Address"
                  placeholderTextColor="#94A3B8"
                />
                {editEmail.length > 0 && (
                  <TouchableOpacity style={styles.clearFieldBtn} onPress={() => setEditEmail('')}>
                    <ClearTextXSVG />
                  </TouchableOpacity>
                )}
              </View>

              <Text style={[styles.formGroupLabel, { marginTop: 10 }]}>
                Profile Links (Max 5)
              </Text>
              {editLinks.map((lnk, idx) => (
                <View key={idx} style={styles.videoInputRow}>
                  <View style={styles.socialCirclePreviewBtn}>
                    {getSocialLogoSVG(lnk)}
                  </View>
                  <View style={[styles.inputWithClearRow, { flex: 1 }]}>
                    <TextInput
                      style={[styles.formInput, { flex: 1 }]}
                      value={lnk}
                      onChangeText={(t) => handleLinkTextChange(t, idx)}
                      placeholder={`https://www.figma.com/@username (${idx + 1})`}
                      placeholderTextColor="#94A3B8"
                    />
                    {lnk.length > 0 && (
                      <TouchableOpacity style={styles.clearFieldBtn} onPress={() => handleLinkTextChange('', idx)}>
                        <ClearTextXSVG />
                      </TouchableOpacity>
                    )}
                  </View>
                  <TouchableOpacity
                    style={styles.removeVideoBtn}
                    onPress={() => handleRemoveAccountLink(idx)}
                  >
                    <TrashIconSVG />
                  </TouchableOpacity>
                </View>
              ))}

              {editLinks.length < 5 && (
                <TouchableOpacity style={styles.addMoreVideoBtn} onPress={handleAddAccountLink}>
                  <Text style={styles.addMoreVideoText}>+ Add Profile Link ({editLinks.length}/5)</Text>
                </TouchableOpacity>
              )}

              <TouchableOpacity style={styles.saveAccountSettingsBtn} activeOpacity={0.85} onPress={handleSaveAccountSettings}>
                <Text style={styles.submitBtnText}>Save Account Settings</Text>
              </TouchableOpacity>
            </ScrollView>
          </SafeAreaView>
        </View>
      </Modal>

      {/* ABOUT DECENT CUSTOM DARK OVERLAY MODAL */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={aboutModalVisible}
        onRequestClose={() => setAboutModalVisible(false)}
      >
        <View style={styles.overlayModalBg}>
          <SafeAreaView style={styles.overlayModalContainer}>
            <View style={styles.modalTopBar}>
              <Text style={styles.modalTopTitle}>About DECENT</Text>
              <TouchableOpacity style={styles.closeBtn} onPress={() => setAboutModalVisible(false)}>
                <Text style={styles.closeBtnText}>✕</Text>
              </TouchableOpacity>
            </View>

            <ScrollView contentContainerStyle={{ padding: 20, gap: 14 }}>
              <Text style={styles.aboutHeroTitle}>✦ DECENT v5.2.6 Native</Text>
              <Text style={styles.aboutBodyText}>
                DECENT is an interactive UI/UX portfolio platform designed for creators, product designers, and design system architects.
              </Text>
              <Text style={styles.aboutBodyText}>
                Showcase mobile design systems, responsive web prototypes, case studies, and live interactive Figma canvas viewports natively in one unified application.
              </Text>

              <View style={styles.aboutInfoBox}>
                <Text style={styles.aboutInfoTitle}>Platform Highlights</Text>
                <Text style={styles.aboutInfoItem}>❖ Interactive Figma Prototype Viewports</Text>
                <Text style={styles.aboutInfoItem}>❖ 45+ UI/UX Specialized Tagging</Text>
                <Text style={styles.aboutInfoItem}>❖ Seamless Dark Mode Design</Text>
                <Text style={styles.aboutInfoItem}>❖ Direct Follower & Notification Hub</Text>
              </View>

              <TouchableOpacity
                style={[styles.confirmDeleteBtn, { width: '100%', marginTop: 10 }]}
                onPress={() => setAboutModalVisible(false)}
              >
                <Text style={styles.confirmDeleteText}>Close</Text>
              </TouchableOpacity>
            </ScrollView>
          </SafeAreaView>
        </View>
      </Modal>

      {/* PRIVACY POLICY CUSTOM DARK OVERLAY MODAL */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={privacyModalVisible}
        onRequestClose={() => setPrivacyModalVisible(false)}
      >
        <View style={styles.overlayModalBg}>
          <SafeAreaView style={styles.overlayModalContainer}>
            <View style={styles.modalTopBar}>
              <Text style={styles.modalTopTitle}>Privacy Policy</Text>
              <TouchableOpacity style={styles.closeBtn} onPress={() => setPrivacyModalVisible(false)}>
                <Text style={styles.closeBtnText}>✕</Text>
              </TouchableOpacity>
            </View>

            <ScrollView contentContainerStyle={{ padding: 20, gap: 14 }}>
              <Text style={styles.aboutHeroTitle}>Data Privacy & Control</Text>
              <Text style={styles.aboutBodyText}>
                Your privacy is paramount. DECENT stores your uploaded portfolio packages, account settings, and followed designers securely on your local device storage.
              </Text>

              <View style={styles.aboutInfoBox}>
                <Text style={styles.aboutInfoTitle}>Key Commitments</Text>
                <Text style={styles.aboutInfoItem}>🔒 Local Storage Persistence via AsyncStorage</Text>
                <Text style={styles.aboutInfoItem}>🔒 No Secret Data Harvesting or Third-Party Tracking</Text>
                <Text style={styles.aboutInfoItem}>🔒 Public Privacy Controls (Hide Liked Portfolios)</Text>
              </View>

              <TouchableOpacity
                style={[styles.confirmDeleteBtn, { width: '100%', marginTop: 10 }]}
                onPress={() => setPrivacyModalVisible(false)}
              >
                <Text style={styles.confirmDeleteText}>Close</Text>
              </TouchableOpacity>
            </ScrollView>
          </SafeAreaView>
        </View>
      </Modal>

      {/* FEEDBACK & SUPPORT CUSTOM DARK OVERLAY MODAL WITH FORM & NOTIFY SWITCH */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={feedbackModalVisible}
        onRequestClose={() => setFeedbackModalVisible(false)}
      >
        <View style={styles.overlayModalBg}>
          <SafeAreaView style={styles.overlayModalContainer}>
            <View style={styles.modalTopBar}>
              <Text style={styles.modalTopTitle}>Feedback & Support</Text>
              <TouchableOpacity style={styles.closeBtn} onPress={() => setFeedbackModalVisible(false)}>
                <Text style={styles.closeBtnText}>✕</Text>
              </TouchableOpacity>
            </View>

            <ScrollView contentContainerStyle={{ padding: 20, gap: 12 }}>
              <View style={styles.knownContactBox}>
                <Text style={styles.knownContactTitle}>Support Contact</Text>
                <Text style={styles.knownContactEmail}>iputra07@gmail.com</Text>
                <Text style={styles.knownContactSub}>Direct inquiries & platform feedback</Text>
              </View>

              <Text style={styles.formGroupLabel}>Your Email Address *</Text>
              <TextInput
                style={styles.formInput}
                placeholder="user@example.com"
                placeholderTextColor="#94A3B8"
                value={feedbackEmail}
                onChangeText={setFeedbackEmail}
              />

              <Text style={styles.formGroupLabel}>Feedback Message or Issue Description *</Text>
              <TextInput
                style={[styles.formInput, { height: 90, textAlignVertical: 'top' }]}
                multiline
                placeholder="Describe your suggestion or technical issue in detail..."
                placeholderTextColor="#94A3B8"
                value={feedbackMessage}
                onChangeText={setFeedbackMessage}
              />

              <View style={styles.feedbackNotifyToggleRow}>
                <View style={{ flex: 1, marginRight: 10 }}>
                  <Text style={styles.settingItemTitle}>Send Email Notification</Text>
                  <Text style={styles.settingItemSub}>
                    Receive an email alert when your reported issue is confirmed and being fixed.
                  </Text>
                </View>
                <Switch
                  value={feedbackNotifyEmail}
                  onValueChange={setFeedbackNotifyEmail}
                  trackColor={{ false: '#26334D', true: '#8B5CF6' }}
                  thumbColor="#FFFFFF"
                />
              </View>

              <TouchableOpacity
                style={[styles.confirmDeleteBtn, { width: '100%', marginTop: 10 }]}
                onPress={handleSubmitFeedback}
              >
                <Text style={styles.confirmDeleteText}>Submit Feedback</Text>
              </TouchableOpacity>
            </ScrollView>
          </SafeAreaView>
        </View>
      </Modal>

      {/* FEEDBACK SUCCESS POPUP MODAL */}
      <Modal
        animationType="fade"
        transparent={true}
        visible={feedbackSuccessModalVisible}
        onRequestClose={() => setFeedbackSuccessModalVisible(false)}
      >
        <View style={styles.overlayModalBg}>
          <View style={styles.customConfirmCard}>
            <View style={styles.successIconCircle}>
              <CheckIconSVG />
            </View>
            <Text style={styles.confirmTitle}>Feedback Submitted</Text>
            <Text style={styles.confirmSubText}>
              Thank you for helping improve DECENT! Our support team (iputra07@gmail.com) has received your submission.
            </Text>
            <TouchableOpacity
              style={[styles.confirmDeleteBtn, { width: '100%', marginTop: 8 }]}
              onPress={() => setFeedbackSuccessModalVisible(false)}
            >
              <Text style={styles.confirmDeleteText}>Continue</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* DONATE CUSTOM DARK OVERLAY MODAL WITH CONTRAST GOLD STYLING */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={donateModalVisible}
        onRequestClose={() => setDonateModalVisible(false)}
      >
        <View style={styles.overlayModalBg}>
          <SafeAreaView style={styles.overlayModalContainer}>
            <View style={styles.modalTopBar}>
              <Text style={styles.modalTopTitle}>Support & Donate to DECENT</Text>
              <TouchableOpacity style={styles.closeBtn} onPress={() => setDonateModalVisible(false)}>
                <Text style={styles.closeBtnText}>✕</Text>
              </TouchableOpacity>
            </View>

            <ScrollView contentContainerStyle={{ padding: 20, gap: 14, alignItems: 'center' }}>
              <View style={styles.donateIconCircle}>
                <Text style={{ fontSize: 24 }}>☕</Text>
              </View>

              <Text style={styles.confirmTitle}>Support Independent Design Tools</Text>
              <Text style={styles.confirmSubText}>
                DECENT is built for UI/UX creators around the world. Your contribution helps keep servers fast and development active!
              </Text>

              <View style={styles.donateTiersRow}>
                <TouchableOpacity style={styles.donateTierChip} onPress={handleDonateConfirm}>
                  <Text style={styles.donateTierText}>$3</Text>
                  <Text style={styles.donateTierSub}>Coffee</Text>
                </TouchableOpacity>

                <TouchableOpacity style={[styles.donateTierChip, styles.donateTierChipActive]} onPress={handleDonateConfirm}>
                  <Text style={styles.donateTierTextActive}>$5</Text>
                  <Text style={styles.donateTierSubActive}>Popular</Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.donateTierChip} onPress={handleDonateConfirm}>
                  <Text style={styles.donateTierText}>$10</Text>
                  <Text style={styles.donateTierSub}>Supporter</Text>
                </TouchableOpacity>
              </View>

              <TouchableOpacity
                style={styles.contrastDonateBtnFull}
                activeOpacity={0.88}
                onPress={handleDonateConfirm}
              >
                <Text style={styles.contrastDonateBtnText}>Donate via Buy Me a Coffee / PayPal</Text>
              </TouchableOpacity>
            </ScrollView>
          </SafeAreaView>
        </View>
      </Modal>

      {/* DONATE SUCCESS POPUP MODAL */}
      <Modal
        animationType="fade"
        transparent={true}
        visible={donateSuccessModalVisible}
        onRequestClose={() => setDonateSuccessModalVisible(false)}
      >
        <View style={styles.overlayModalBg}>
          <View style={styles.customConfirmCard}>
            <View style={styles.successIconCircle}>
              <CheckIconSVG />
            </View>
            <Text style={styles.confirmTitle}>Thank You!</Text>
            <Text style={styles.confirmSubText}>
              Your generosity keeps DECENT independent and growing. We greatly appreciate your support!
            </Text>
            <TouchableOpacity
              style={[styles.confirmDeleteBtn, { width: '100%', marginTop: 8 }]}
              onPress={() => setDonateSuccessModalVisible(false)}
            >
              <Text style={styles.confirmDeleteText}>Continue</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* APP SETTINGS MODAL WITH DONATE BUTTON AT VERY BOTTOM */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={settingsModalVisible}
        onRequestClose={() => setSettingsModalVisible(false)}
      >
        <View style={styles.overlayModalBg}>
          <SafeAreaView style={styles.overlayModalContainer}>
            <View style={styles.modalTopBar}>
              <Text style={styles.modalTopTitle}>App Settings</Text>
              <TouchableOpacity style={styles.closeBtn} onPress={() => setSettingsModalVisible(false)}>
                <Text style={styles.closeBtnText}>✕</Text>
              </TouchableOpacity>
            </View>

            <ScrollView contentContainerStyle={{ padding: 20, gap: 14 }}>
              <TouchableOpacity
                style={styles.settingItemRow}
                onPress={() => {
                  setSettingsModalVisible(false);
                  handleOpenAccountSettingsModal();
                }}
              >
                <Text style={styles.settingItemTitle}>Account Settings</Text>
                <View style={styles.iconTextInlineRow}>
                  <Text style={styles.settingItemValue}>Edit Profile</Text>
                  <ChevronRightSVG color="#C084FC" size={16} />
                </View>
              </TouchableOpacity>

              <View style={styles.settingToggleRow}>
                <View style={{ flex: 1, marginRight: 10 }}>
                  <Text style={styles.settingItemTitle}>Hide Liked Portfolios from Public</Text>
                  <Text style={styles.settingItemSub}>
                    When enabled, visitors can only see your uploaded portfolios on your profile page.
                  </Text>
                </View>
                <Switch
                  value={hideLikedPortfolios}
                  onValueChange={setHideLikedPortfolios}
                  trackColor={{ false: '#26334D', true: '#8B5CF6' }}
                  thumbColor="#FFFFFF"
                />
              </View>

              <View style={styles.settingItemRow}>
                <Text style={styles.settingItemTitle}>App Version</Text>
                <Text style={styles.settingItemValue}>v5.2.6 Native</Text>
              </View>

              <TouchableOpacity
                style={styles.settingItemRow}
                onPress={() => setAboutModalVisible(true)}
              >
                <Text style={styles.settingItemTitle}>About DECENT</Text>
                <View style={styles.iconTextInlineRow}>
                  <Text style={styles.settingItemValue}>Information</Text>
                  <ChevronRightSVG color="#C084FC" size={16} />
                </View>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.settingItemRow}
                onPress={() => setPrivacyModalVisible(true)}
              >
                <Text style={styles.settingItemTitle}>Privacy Policy</Text>
                <View style={styles.iconTextInlineRow}>
                  <Text style={styles.settingItemValue}>View Policy</Text>
                  <ChevronRightSVG color="#C084FC" size={16} />
                </View>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.settingItemRow}
                onPress={() => setFeedbackModalVisible(true)}
              >
                <Text style={styles.settingItemTitle}>Feedback & Support</Text>
                <View style={styles.iconTextInlineRow}>
                  <Text style={styles.settingItemValue}>Send Message</Text>
                  <ChevronRightSVG color="#C084FC" size={16} />
                </View>
              </TouchableOpacity>

              {/* Contrast Donate Button at Very Bottom */}
              <TouchableOpacity
                style={styles.donateSettingBtn}
                activeOpacity={0.88}
                onPress={() => setDonateModalVisible(true)}
              >
                <Text style={styles.donateSettingBtnText}>☕ Support & Donate to DECENT</Text>
              </TouchableOpacity>
            </ScrollView>
          </SafeAreaView>
        </View>
      </Modal>

      {/* ALL 20 CATEGORIES POPUP OVERLAY MODAL */}
      <Modal
        animationType="fade"
        transparent={true}
        visible={allCategoriesModalVisible}
        onRequestClose={() => setAllCategoriesModalVisible(false)}
      >
        <View style={styles.overlayModalBg}>
          <SafeAreaView style={styles.overlayModalContainer}>
            <View style={styles.modalTopBar}>
              <Text style={styles.modalTopTitle}>All Categories</Text>
              <TouchableOpacity style={styles.closeBtn} onPress={() => setAllCategoriesModalVisible(false)}>
                <Text style={styles.closeBtnText}>✕</Text>
              </TouchableOpacity>
            </View>

            <ScrollView contentContainerStyle={styles.allCategoriesGrid}>
              {ALL_UIUX_CATEGORIES_MASTER.slice(0, 20).map((cat) => (
                <TouchableOpacity
                  key={cat}
                  style={[styles.overlayCategoryCard, categoryFilter === cat && styles.overlayCategoryCardActive]}
                  onPress={() => {
                    setCategoryFilter(cat);
                    setAllCategoriesModalVisible(false);
                  }}
                >
                  <Text style={[styles.overlayCategoryText, categoryFilter === cat && styles.overlayCategoryTextActive]}>
                    {cat}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </SafeAreaView>
        </View>
      </Modal>

      {/* FOLLOWERS / FOLLOWING USER LIST MODAL */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={userListModalVisible}
        onRequestClose={() => setUserListModalVisible(false)}
      >
        <View style={styles.overlayModalBg}>
          <SafeAreaView style={styles.overlayModalContainer}>
            <View style={styles.modalTopBar}>
              <Text style={styles.modalTopTitle}>{userListTitle}</Text>
              <TouchableOpacity style={styles.closeBtn} onPress={() => setUserListModalVisible(false)}>
                <Text style={styles.closeBtnText}>✕</Text>
              </TouchableOpacity>
            </View>

            <ScrollView contentContainerStyle={{ padding: 16, gap: 12 }}>
              {userListItems.map((usr) => {
                const isFollowing = followedDesigners.includes(usr.name);
                return (
                  <TouchableOpacity
                    key={usr.id}
                    style={styles.designerItemCard}
                    onPress={() => {
                      setUserListModalVisible(false);
                      openDesignerModal(usr);
                    }}
                  >
                    <Image source={{ uri: usr.avatar }} style={styles.designerListAvatar} />
                    <View style={styles.designerInfoCol}>
                      <Text style={styles.designerListName}>{usr.name}</Text>
                      <Text style={styles.designerListRole}>{usr.role}</Text>
                    </View>

                    <TouchableOpacity
                      style={[styles.smallFollowBtn, isFollowing && styles.smallFollowBtnActive]}
                      onPress={() => toggleFollowDesigner(usr.name)}
                    >
                      <Text style={[styles.smallFollowText, isFollowing && styles.smallFollowTextActive]}>
                        {isFollowing ? 'Following' : '+ Follow Back'}
                      </Text>
                    </TouchableOpacity>
                  </TouchableOpacity>
                );
              })}
            </ScrollView>
          </SafeAreaView>
        </View>
      </Modal>

      {/* DESIGNER PROFILE MODAL */}
      {selectedDesigner && (
        <Modal
          animationType="slide"
          transparent={false}
          visible={designerModalVisible}
          onRequestClose={() => setDesignerModalVisible(false)}
        >
          <SafeAreaView style={styles.modalContainer}>
            <View style={styles.modalTopBar}>
              <Text style={styles.modalTopTitle}>Designer Profile</Text>
              <TouchableOpacity style={styles.closeBtn} onPress={() => setDesignerModalVisible(false)}>
                <Text style={styles.closeBtnText}>✕</Text>
              </TouchableOpacity>
            </View>

            <ScrollView style={styles.caseScrollView} contentContainerStyle={styles.caseContent}>
              <View style={styles.profileCard}>
                <Image source={{ uri: selectedDesigner.avatar }} style={styles.profileLargeAvatar} />
                <Text style={styles.profileName}>{selectedDesigner.name}</Text>
                <Text style={styles.profileRole}>{selectedDesigner.role}</Text>
                
                <View style={[styles.iconTextInlineRow, { marginBottom: 12 }]}>
                  <LocationPinSVG />
                  <Text style={styles.profileLocText}>{selectedDesigner.location}</Text>
                </View>

                <Text style={styles.profileBio}>{selectedDesigner.bio}</Text>

                <View style={styles.statsRow}>
                  <TouchableOpacity
                    style={styles.statItem}
                    onPress={() => openFollowersModal(selectedDesigner)}
                  >
                    <Text style={styles.statNum}>{selectedDesigner.followersCount || 1240}</Text>
                    <Text style={styles.statLabel}>Followers</Text>
                  </TouchableOpacity>

                  <View style={styles.statDivider} />

                  <TouchableOpacity
                    style={styles.statItem}
                    onPress={() => openFollowingModal(selectedDesigner)}
                  >
                    <Text style={styles.statNum}>{selectedDesigner.followingCount || 280}</Text>
                    <Text style={styles.statLabel}>Following</Text>
                  </TouchableOpacity>
                </View>

                {selectedDesigner.links && selectedDesigner.links.length > 0 && (
                  <View style={styles.socialCircularLinksRow}>
                    {selectedDesigner.links.map((linkUrl, idx) => (
                      <TouchableOpacity
                        key={idx}
                        style={styles.socialCircleBtn}
                        onPress={() => openExternalLinkWithWarning(linkUrl)}
                      >
                        {getSocialLogoSVG(linkUrl)}
                      </TouchableOpacity>
                    ))}
                  </View>
                )}

                <View style={[styles.designerProfileActionsRow, { marginTop: 14 }]}>
                  <TouchableOpacity
                    style={[
                      styles.modalFollowBtn,
                      followedDesigners.includes(selectedDesigner.name) && styles.modalFollowBtnActive
                    ]}
                    onPress={() => toggleFollowDesigner(selectedDesigner.name)}
                  >
                    <Text style={[
                      styles.modalFollowText,
                      followedDesigners.includes(selectedDesigner.name) && styles.modalFollowTextActive
                    ]}>
                      {followedDesigners.includes(selectedDesigner.name) ? 'Following' : '+ Follow Back'}
                    </Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={styles.modalShareBtnIconOnly}
                    onPress={() => handleShareDesigner(selectedDesigner)}
                  >
                    <ShareIconSVG />
                  </TouchableOpacity>
                </View>
              </View>

              <View style={styles.profileTabsBar}>
                <TouchableOpacity
                  style={[styles.profileTabBtn, designerProfileTab === 'myWork' && styles.profileTabBtnActive]}
                  onPress={() => setDesignerProfileTab('myWork')}
                >
                  <Text style={[styles.profileTabBtnText, designerProfileTab === 'myWork' && styles.profileTabBtnTextActive]}>
                    Portfolios ({projects.filter((p) => p.designer.toLowerCase().includes(selectedDesigner.name.split(' ')[0].toLowerCase())).length})
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[styles.profileTabBtn, designerProfileTab === 'likedWork' && styles.profileTabBtnActive]}
                  onPress={() => setDesignerProfileTab('likedWork')}
                >
                  <Text style={[styles.profileTabBtnText, designerProfileTab === 'likedWork' && styles.profileTabBtnTextActive]}>
                    Liked Portfolios ({myLikedProjects.length})
                  </Text>
                </TouchableOpacity>
              </View>

              <TwoRowHorizontalGrid
                items={
                  designerProfileTab === 'myWork'
                    ? projects.filter((p) => p.designer.toLowerCase().includes(selectedDesigner.name.split(' ')[0].toLowerCase()))
                    : myLikedProjects
                }
                onPress={(item) => {
                  setDesignerModalVisible(false);
                  openProjectModal(item);
                }}
                onOpenDesignerProfile={openDesignerProfileByName}
                onToggleFollow={toggleFollowDesigner}
                followedDesigners={followedDesigners}
              />
            </ScrollView>
          </SafeAreaView>
        </Modal>
      )}

      {/* 4-STEP WIZARD MODAL FOR ADDING/EDITING PORTFOLIO PACKAGE */}
      <Modal
        animationType="slide"
        transparent={false}
        visible={addModalVisible}
        onRequestClose={() => setAddModalVisible(false)}
      >
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalTopBar}>
            <Text style={styles.modalTopTitle}>
              {editingProjectId ? 'Edit Portfolio Package' : 'Add Portfolio Package'} (Step {formStep}/4)
            </Text>
            <TouchableOpacity style={styles.closeBtn} onPress={() => setAddModalVisible(false)}>
              <Text style={styles.closeBtnText}>✕</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.stepProgressBar}>
            <View style={styles.stepProgressItem}>
              {fTitle.trim() && fBrief.trim() && fCategories.length > 0 ? <CheckIconSVG /> : <DetailsStepSVG color={formStep === 1 ? '#8B5CF6' : '#94A3B8'} />}
              <Text style={[styles.stepLabel, formStep === 1 && styles.stepLabelActive]}>Details</Text>
            </View>
            <View style={styles.stepDivider} />

            <View style={styles.stepProgressItem}>
              {step2Skipped ? <Circle cx="8" cy="8" r="4" fill="#FFFFFF" /> : (fFigmaProto.trim() || fDesktopProto.trim() || fFigmaFile.trim()) ? <CheckIconSVG /> : <LinksStepSVG color={formStep === 2 ? '#8B5CF6' : '#94A3B8'} />}
              <Text style={[styles.stepLabel, formStep === 2 && styles.stepLabelActive]}>Links</Text>
            </View>
            <View style={styles.stepDivider} />

            <View style={styles.stepProgressItem}>
              {fCover.trim() && fShowcaseImages.filter(img => img.trim()).length >= 2 ? <CheckIconSVG /> : <MediaStepSVG color={formStep === 3 ? '#8B5CF6' : '#94A3B8'} />}
              <Text style={[styles.stepLabel, formStep === 3 && styles.stepLabelActive]}>Media</Text>
            </View>
            <View style={styles.stepDivider} />

            <View style={styles.stepProgressItem}>
              <ReviewStepSVG color={formStep === 4 ? '#8B5CF6' : '#94A3B8'} />
              <Text style={[styles.stepLabel, formStep === 4 && styles.stepLabelActive]}>Review</Text>
            </View>
          </View>

          <KeyboardAvoidingView
            style={{ flex: 1 }}
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
          >
            <ScrollView style={styles.caseScrollView} contentContainerStyle={[styles.caseContent, { paddingBottom: 110 }]}>
              {formStep === 1 && (
                <View>
                  <Text style={styles.stepSectionTitle}>1. Portfolio Details & Brief (Mandatory)</Text>

                  <Text style={styles.formGroupLabel}>Project Title *</Text>
                  <TextInput
                    style={[styles.formInput, errors.fTitle && styles.inputErrorBorder]}
                    placeholder="e.g. Smart FinTech App"
                    placeholderTextColor="#94A3B8"
                    value={fTitle}
                    onChangeText={(t) => { setFTitle(t); setErrors({ ...errors, fTitle: null }); }}
                  />
                  {errors.fTitle ? <Text style={styles.errorText}>{errors.fTitle}</Text> : null}

                  <Text style={styles.formGroupLabel}>Designer Name</Text>
                  <TextInput
                    style={styles.formInput}
                    placeholder="e.g. Iqbal Aprianda Putra"
                    placeholderTextColor="#94A3B8"
                    value={fDesigner}
                    onChangeText={setFDesigner}
                  />

                  <View style={{ marginTop: 12 }}>
                    <Text style={styles.formGroupLabel}>
                      Categories & Tags * (Selected: {fCategories.length}/5)
                    </Text>

                    <TextInput
                      style={styles.categorySearchInput}
                      placeholder="Search or add custom category/tag..."
                      placeholderTextColor="#94A3B8"
                      value={categorySearchQuery}
                      onChangeText={(t) => {
                        setCategorySearchQuery(t);
                        setIsCategorySearchActive(t.length > 0);
                      }}
                      onFocus={() => setIsCategorySearchActive(true)}
                    />

                    {fCategories.length > 0 && (
                      <View style={styles.selectedCategoriesRow}>
                        {fCategories.map((cat) => (
                          <TouchableOpacity
                            key={cat}
                            style={styles.selectedCategoryPill}
                            onPress={() => toggleCategorySelection(cat)}
                          >
                            <Text style={styles.selectedCategoryText}>{cat} ✕</Text>
                          </TouchableOpacity>
                        ))}
                      </View>
                    )}

                    {isCategorySearchActive ? (
                      <View style={styles.categoryVerticalListContainer}>
                        <ScrollView style={{ maxHeight: 200 }} nestedScrollEnabled={true}>
                          {filteredCategoriesForWizard.map((cat) => {
                            const isSelected = fCategories.includes(cat);
                            return (
                              <TouchableOpacity
                                key={cat}
                                style={[
                                  styles.categoryVerticalItem,
                                  isSelected && styles.categoryVerticalItemActive
                                ]}
                                onPress={() => toggleCategorySelection(cat)}
                              >
                                <Text style={[
                                  styles.categoryVerticalText,
                                  isSelected && styles.categoryVerticalTextActive
                                ]}>
                                  {isSelected ? '✓ ' : ''}{cat}
                                </Text>
                              </TouchableOpacity>
                            );
                          })}

                          {filteredCategoriesForWizard.length === 0 && categorySearchQuery.trim() !== '' && (
                            <TouchableOpacity
                              style={styles.addCustomCategoryItemBtn}
                              onPress={handleAddCustomCategory}
                            >
                              <Text style={styles.addCustomCategoryItemText}>
                                + Add Custom Category "{categorySearchQuery.trim()}"
                              </Text>
                            </TouchableOpacity>
                          )}
                        </ScrollView>
                      </View>
                    ) : (
                      <View style={styles.categoryPillsRow}>
                        {DEFAULT_POPULAR_CATEGORY_CHIPS.map((cat) => {
                          const isSelected = fCategories.includes(cat);
                          return (
                            <TouchableOpacity
                              key={cat}
                              style={[styles.categoryPill, isSelected && styles.categoryPillActive]}
                              onPress={() => toggleCategorySelection(cat)}
                            >
                              <Text style={[styles.categoryPillText, isSelected && styles.categoryPillTextActive]}>
                                {isSelected ? '✓ ' : ''}{cat}
                              </Text>
                            </TouchableOpacity>
                          );
                        })}

                        <TouchableOpacity
                          style={styles.moreCategoriesChip}
                          onPress={() => setIsCategorySearchActive(true)}
                        >
                          <Text style={styles.moreCategoriesText}>+ Search All 45+ Tags</Text>
                        </TouchableOpacity>
                      </View>
                    )}

                    {errors.fCategories ? <Text style={styles.errorText}>{errors.fCategories}</Text> : null}
                  </View>

                  <Text style={[styles.formGroupLabel, { marginTop: 14 }]}>Short Brief / Summary *</Text>
                  <TextInput
                    style={[styles.formInput, { height: 80 }, errors.fBrief && styles.inputErrorBorder]}
                    multiline
                    placeholder="1-2 sentences summarizing goals and outcome..."
                    placeholderTextColor="#94A3B8"
                    value={fBrief}
                    onChangeText={(t) => { setFBrief(t); setErrors({ ...errors, fBrief: null }); }}
                  />
                  {errors.fBrief ? <Text style={styles.errorText}>{errors.fBrief}</Text> : null}
                </View>
              )}

              {formStep === 2 && (
                <View>
                  <Text style={styles.stepSectionTitle}>2. Prototype & Design Links (Optional)</Text>

                  <View style={styles.warningNoteBox}>
                    <View style={styles.iconTextInlineRow}>
                      <WarningTriangleSVG />
                      <Text style={styles.warningTitle}>Prototype Compatibility Note</Text>
                    </View>
                    <Text style={styles.warningText}>
                      Embedded prototype viewports currently support Figma share/embed links. All fields in this step are optional.
                    </Text>
                  </View>

                  <Text style={styles.formGroupLabel}>Figma Mobile Prototype Share Link</Text>
                  <TextInput
                    style={styles.formInput}
                    placeholder="https://www.figma.com/proto/..."
                    placeholderTextColor="#94A3B8"
                    value={fFigmaProto}
                    onChangeText={setFFigmaProto}
                  />

                  <Text style={styles.formGroupLabel}>Figma Desktop Prototype Share Link</Text>
                  <TextInput
                    style={styles.formInput}
                    placeholder="https://www.figma.com/proto/... (1440px canvas)"
                    placeholderTextColor="#94A3B8"
                    value={fDesktopProto}
                    onChangeText={setFDesktopProto}
                  />

                  <Text style={styles.formGroupLabel}>Figma Design File Canvas Link (Inspect Mode)</Text>
                  <TextInput
                    style={styles.formInput}
                    placeholder="https://www.figma.com/design/..."
                    placeholderTextColor="#94A3B8"
                    value={fFigmaFile}
                    onChangeText={setFFigmaFile}
                  />

                  <Text style={styles.formGroupLabel}>Figma Profile Link</Text>
                  <TextInput
                    style={styles.formInput}
                    placeholder="https://www.figma.com/@username"
                    placeholderTextColor="#94A3B8"
                    value={fFigmaProfile}
                    onChangeText={setFFigmaProfile}
                  />
                </View>
              )}

              {formStep === 3 && (
                <View>
                  <Text style={styles.stepSectionTitle}>3. Media, Local Uploads & Video Demos</Text>

                  <Text style={styles.formGroupLabel}>Cover Thumbnail Photo * (Big Rectangle)</Text>
                  <TouchableOpacity
                    style={[styles.bigRectanglePicker, errors.fCover && styles.inputErrorBorder]}
                    activeOpacity={0.8}
                    onPress={pickCoverImage}
                  >
                    {fCover ? (
                      <Image source={{ uri: fCover }} style={styles.bigRectanglePreview} />
                    ) : (
                      <View style={styles.pickerPlaceholderCol}>
                        <ImageIconSVG />
                        <Text style={styles.pickerTextMain}>Tap to Pick Cover Thumbnail Photo</Text>
                        <Text style={styles.pickerSubText}>Browse local photos from your Phone or PC</Text>
                      </View>
                    )}
                  </TouchableOpacity>
                  {errors.fCover ? <Text style={styles.errorText}>{errors.fCover}</Text> : null}

                  <Text style={[styles.formGroupLabel, { marginTop: 20 }]}>
                    Picture Showcase Highlights * (At least 2 required, up to 10)
                  </Text>
                  <View style={styles.smallSquaresGrid}>
                    {fShowcaseImages.map((imgUri, index) => (
                      <View key={index} style={styles.squarePickerWrapper}>
                        <TouchableOpacity
                          style={[styles.smallSquarePicker, errors.showcaseImages && styles.inputErrorBorder]}
                          activeOpacity={0.8}
                          onPress={() => pickShowcaseImageAtIndex(index)}
                        >
                          {imgUri ? (
                            <Image source={{ uri: imgUri }} style={styles.smallSquarePreview} />
                          ) : (
                            <View style={styles.pickerPlaceholderCol}>
                              <CameraIconSVG />
                              <Text style={styles.squarePickerText}>Img {index + 1}</Text>
                            </View>
                          )}
                        </TouchableOpacity>

                        {fShowcaseImages.length > 2 && (
                          <TouchableOpacity
                            style={styles.removeImageBadge}
                            onPress={() => handleRemoveShowcaseImage(index)}
                          >
                            <TrashIconSVG />
                          </TouchableOpacity>
                        )}
                      </View>
                    ))}
                  </View>

                  {fShowcaseImages.length < 10 && (
                    <TouchableOpacity style={styles.addMoreVideoBtn} onPress={handleAddShowcaseImage}>
                      <Text style={styles.addMoreVideoText}>+ Add Showcase Image ({fShowcaseImages.length}/10)</Text>
                    </TouchableOpacity>
                  )}
                  {errors.showcaseImages ? (
                    <Text style={styles.errorText}>{errors.showcaseImages}</Text>
                  ) : null}

                  <Text style={[styles.formGroupLabel, { marginTop: 20 }]}>Video Demo Links (Optional - YouTube/Vimeo)</Text>
                  {fVideoLinks.map((vid, idx) => (
                    <View key={idx} style={styles.videoInputRow}>
                      <TextInput
                        style={[styles.formInput, { flex: 1 }]}
                        placeholder={`https://www.youtube.com/watch?v=... (${idx + 1})`}
                        placeholderTextColor="#94A3B8"
                        value={vid}
                        onChangeText={(t) => handleVideoUrlChange(t, idx)}
                      />
                      {fVideoLinks.length > 1 && (
                        <TouchableOpacity
                          style={styles.removeVideoBtn}
                          onPress={() => handleRemoveVideoLink(idx)}
                        >
                          <TrashIconSVG />
                        </TouchableOpacity>
                      )}
                    </View>
                  ))}

                  <TouchableOpacity style={styles.addMoreVideoBtn} onPress={handleAddMoreVideo}>
                    <Text style={styles.addMoreVideoText}>+ Add More Video Links</Text>
                  </TouchableOpacity>
                </View>
              )}

              {formStep === 4 && (
                <View>
                  <Text style={styles.stepSectionTitle}>4. Confirm & Post Package</Text>

                  <View style={styles.confirmReviewCard}>
                    {fCover ? <Image source={{ uri: fCover }} style={styles.reviewCover} /> : null}
                    <Text style={styles.reviewTitle}>{fTitle}</Text>
                    <Text style={styles.reviewDesigner}>By {fDesigner}</Text>
                    <Text style={styles.reviewCategory}>Categories: {fCategories.join(', ')}</Text>
                    <Text style={styles.reviewBrief}>{fBrief}</Text>

                    <View style={styles.reviewSummaryRow}>
                      <Text style={styles.reviewStat}>❖ Mobile Proto: {fFigmaProto ? 'Attached' : 'None'}</Text>
                      <Text style={styles.reviewStat}>💻 Desktop Proto: {fDesktopProto ? 'Attached' : 'None'}</Text>
                      <Text style={styles.reviewStat}>🖼 Showcase Images: {fShowcaseImages.filter(v => v.trim()).length} Picked</Text>
                      <Text style={styles.reviewStat}>🎬 Video Demos: {fVideoLinks.filter(v => v.trim()).length} Attached</Text>
                    </View>
                  </View>
                </View>
              )}

            </ScrollView>

            <View style={styles.stickyWizardBottomBar}>
              {formStep > 1 && (
                <TouchableOpacity style={styles.uniformWizardBtnBack} onPress={() => setFormStep(formStep - 1)}>
                  <View style={styles.iconTextInlineRow}>
                    <ChevronLeftSVG color="#94A3B8" size={16} />
                    <Text style={styles.backBtnText}>Back</Text>
                  </View>
                </TouchableOpacity>
              )}

              {formStep === 2 && (
                <TouchableOpacity style={styles.uniformWizardBtnSkip} onPress={() => handleNextFromStep2(true)}>
                  <Text style={styles.skipBtnText}>Skip Step</Text>
                </TouchableOpacity>
              )}

              <TouchableOpacity
                style={styles.uniformWizardBtnPrimary}
                onPress={() => {
                  if (formStep === 1) handleNextFromStep1();
                  else if (formStep === 2) handleNextFromStep2(false);
                  else if (formStep === 3) handleNextFromStep3();
                  else if (formStep === 4) handleFinalPostPackage();
                }}
              >
                <View style={styles.iconTextInlineRow}>
                  <Text style={styles.submitBtnText}>
                    {formStep === 1 ? 'Next: Add Links' :
                     formStep === 2 ? 'Next: Media' :
                     formStep === 3 ? 'Review & Confirm' :
                     editingProjectId ? 'Update Portfolio Package' : 'Post Portfolio Package'}
                  </Text>
                  <ChevronRightSVG color="#FFFFFF" size={18} />
                </View>
              </TouchableOpacity>
            </View>
          </KeyboardAvoidingView>
        </SafeAreaView>
      </Modal>

      {/* Native Fullscreen Showcase Modal with Sticky Title Bar and Jump-to-Top Button */}
      {activeProject && (
        <Modal
          animationType="slide"
          transparent={false}
          visible={modalVisible}
          onRequestClose={() => setModalVisible(false)}
        >
          <SafeAreaView style={styles.modalContainer}>
            <View style={styles.modalTopBar}>
              <View style={styles.leftAlignedEngagementStatsRow}>
                <TouchableOpacity style={styles.statInlinePill} onPress={() => toggleLike(activeProject.id)}>
                  <HeartIconSVG liked={activeProject.liked} />
                  <Text style={styles.statInlineNumText}>{activeProject.likesCount || 1}</Text>
                </TouchableOpacity>

                <View style={styles.statInlinePill}>
                  <EyeViewIconSVG />
                  <Text style={styles.statInlineNumText}>{activeProject.visitsCount || 120}</Text>
                </View>
              </View>

              {activeProject.designer.toLowerCase().includes('iqbal') && (
                <View style={styles.ownerActionsRow}>
                  <TouchableOpacity
                    style={styles.ownerIconBtn}
                    onPress={() => openEditWizard(activeProject)}
                  >
                    <EditIconSVG />
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={styles.ownerIconBtn}
                    onPress={() => promptDeletePortfolio(activeProject)}
                  >
                    <TrashIconSVG />
                  </TouchableOpacity>
                </View>
              )}

              <TouchableOpacity style={styles.closeBtn} onPress={() => setModalVisible(false)}>
                <Text style={styles.closeBtnText}>✕</Text>
              </TouchableOpacity>
            </View>

            {/* Sticky Portfolio Title Bar directly under top bar */}
            <View style={styles.stickyModalTitleBar}>
              <Text style={styles.stickyModalTitleText} numberOfLines={1}>
                {activeProject.title}
              </Text>
            </View>

            <View style={styles.tabBar}>
              <TouchableOpacity
                style={[styles.tabBtn, activeTab === 'case' && styles.tabBtnActive]}
                onPress={() => setActiveTab('case')}
              >
                <Text style={[styles.tabBtnText, activeTab === 'case' && styles.tabBtnTextActive]}>
                  Case Study
                </Text>
              </TouchableOpacity>

              {activeProject.figmaProto ? (
                <TouchableOpacity
                  style={[styles.tabBtn, activeTab === 'mobile' && styles.tabBtnActive]}
                  onPress={() => { setActiveTab('mobile'); setLoadingWebView(true); }}
                >
                  <Text style={[styles.tabBtnText, activeTab === 'mobile' && styles.tabBtnTextActive]}>
                    Mobile View
                  </Text>
                </TouchableOpacity>
              ) : null}

              {activeProject.desktopProto ? (
                <TouchableOpacity
                  style={[styles.tabBtn, activeTab === 'desktop' && styles.tabBtnActive]}
                  onPress={() => { setActiveTab('desktop'); setLoadingWebView(true); }}
                >
                  <Text style={[styles.tabBtnText, activeTab === 'desktop' && styles.tabBtnTextActive]}>
                    Desktop View
                  </Text>
                </TouchableOpacity>
              ) : null}
            </View>

            <View style={styles.modalBody}>
              {activeTab === 'mobile' || activeTab === 'desktop' ? (
                <View style={styles.webViewWrapper}>
                  {loadingWebView && (
                    <View style={styles.loaderOverlay}>
                      <ActivityIndicator size="large" color="#8B5CF6" />
                      <Text style={styles.loaderText}>Loading Figma Prototype...</Text>
                    </View>
                  )}
                  <WebView
                    source={{
                      uri: getFigmaEmbedUrl(
                        activeTab === 'desktop'
                          ? activeProject.desktopProto
                          : activeProject.figmaProto
                      )
                    }}
                    style={styles.webView}
                    onLoadEnd={() => setLoadingWebView(false)}
                    onShouldStartLoadWithRequest={handleWebViewNavigation}
                    javaScriptEnabled={true}
                    domStorageEnabled={true}
                  />
                </View>
              ) : (
                <ScrollView
                  ref={modalScrollViewRef}
                  style={styles.caseScrollView}
                  contentContainerStyle={[styles.caseContent, { paddingBottom: 110 }]}
                  onScroll={handleModalScroll}
                  scrollEventThrottle={16}
                >
                  {/* Designer Row with Right-Aligned Follow/Following Button */}
                  <View style={styles.designerRowModal}>
                    <TouchableOpacity
                      style={styles.designerRowModalLeftCol}
                      activeOpacity={0.7}
                      onPress={() => openDesignerProfileByName(activeProject.designer)}
                    >
                      <Image
                        source={{ uri: activeProject.designerAvatar }}
                        style={styles.designerAvatarModal}
                      />
                      <View style={{ flex: 1, marginRight: 8 }}>
                        <Text style={styles.caseDesigner}>By {activeProject.designer}</Text>
                        <Text style={styles.caseDesignerRole}>{getDesignerRole(activeProject.designer)}</Text>
                      </View>
                    </TouchableOpacity>

                    {/* Follow/Following Button Aligned Right */}
                    {activeProject.designer.toLowerCase() !== userProfile.name.toLowerCase() && (
                      <TouchableOpacity
                        style={[
                          styles.modalDesignerFollowBtnRight,
                          followedDesigners.includes(activeProject.designer) && styles.modalDesignerFollowBtnRightActive
                        ]}
                        onPress={() => toggleFollowDesigner(activeProject.designer)}
                      >
                        <Text style={[
                          styles.modalDesignerFollowTextRight,
                          followedDesigners.includes(activeProject.designer) && styles.modalDesignerFollowTextRightActive
                        ]}>
                          {followedDesigners.includes(activeProject.designer) ? 'Following' : '+ Follow Back'}
                        </Text>
                      </TouchableOpacity>
                    )}
                  </View>

                  {/* ONLY Show Figma Design Canvas Link If Included by User */}
                  {activeProject.figmaFile && activeProject.figmaFile.trim() !== '' ? (
                    <View style={styles.chipRow}>
                      <TouchableOpacity
                        style={styles.linkChip}
                        onPress={() => openExternalLinkWithWarning(activeProject.figmaFile)}
                      >
                        <Text style={styles.linkChipText}>❖ Open Figma Design Canvas ↗</Text>
                      </TouchableOpacity>
                    </View>
                  ) : null}

                  <View style={styles.briefBox}>
                    <Text style={styles.briefText}>{activeProject.brief}</Text>
                  </View>

                  <Text style={styles.sectionHeader}>UI SCREENSHOTS & HIGHLIGHTS</Text>
                  <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.galleryScroll}>
                    {activeProject.images.map((imgUrl, index) => (
                      <Image key={index} source={{ uri: imgUrl }} style={styles.galleryImage} />
                    ))}
                  </ScrollView>

                  <Text style={styles.sectionHeader}>CASE STUDY OVERVIEW</Text>
                  <Text style={styles.caseBodyText}>{activeProject.caseStudy}</Text>
                </ScrollView>
              )}

              {/* Showcase Jump To Top Floating Button (On Top of Sticky Like Button, Shows on Scroll) */}
              {showModalBackToTop && (
                <TouchableOpacity
                  style={styles.stickyModalBackToTopBtn}
                  activeOpacity={0.85}
                  onPress={scrollModalToTop}
                >
                  <ChevronUpSVG />
                </TouchableOpacity>
              )}

              {/* Floating Circle Like Button (Full Opacity Container, Only Heart Icon Turns Red) */}
              <TouchableOpacity
                style={styles.floatingLikeCircleBtn}
                activeOpacity={0.88}
                onPress={() => toggleLike(activeProject.id)}
              >
                <HeartIconSVG liked={activeProject.liked} />
              </TouchableOpacity>

            </View>
          </SafeAreaView>
        </Modal>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  thumbnailContainerCompact: {
    height: 120,
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    overflow: 'hidden'
  },
  cardBodyCompact: {
    padding: 8
  },
  cardTitleCompact: {
    fontSize: 13,
    lineHeight: 17
  },
  donateSettingBtn: {
    backgroundColor: '#F59E0B',
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 14,
    alignItems: 'center',
    marginTop: 10
  },
  donateSettingBtnText: {
    color: '#0B0F17',
    fontSize: 15,
    fontWeight: '700'
  },
  donateIconCircle: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: 'rgba(245, 158, 11, 0.15)',
    borderWidth: 1,
    borderColor: '#F59E0B',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8
  },
  donateTiersRow: {
    flexDirection: 'row',
    gap: 12,
    marginVertical: 12
  },
  donateTierChip: {
    flex: 1,
    paddingVertical: 12,
    backgroundColor: '#1E293B',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#26334D',
    alignItems: 'center'
  },
  donateTierChipActive: {
    backgroundColor: 'rgba(245, 158, 11, 0.2)',
    borderColor: '#F59E0B'
  },
  donateTierText: {
    color: '#F8FAFC',
    fontSize: 16,
    fontWeight: '700'
  },
  donateTierTextActive: {
    color: '#F59E0B',
    fontSize: 16,
    fontWeight: '700'
  },
  donateTierSub: {
    color: '#94A3B8',
    fontSize: 11,
    marginTop: 2
  },
  donateTierSubActive: {
    color: '#F59E0B',
    fontSize: 11,
    marginTop: 2
  },
  contrastDonateBtnFull: {
    width: '100%',
    backgroundColor: '#F59E0B',
    paddingVertical: 14,
    borderRadius: 14,
    alignItems: 'center',
    marginTop: 8
  },
  contrastDonateBtnText: {
    color: '#0B0F17',
    fontSize: 15,
    fontWeight: '700'
  },
  knownContactBox: {
    padding: 14,
    backgroundColor: '#1E293B',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#26334D',
    marginBottom: 10
  },
  knownContactTitle: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '600'
  },
  knownContactEmail: {
    color: '#C084FC',
    fontSize: 16,
    fontWeight: '700',
    marginTop: 2
  },
  knownContactSub: {
    color: '#64748B',
    fontSize: 11,
    marginTop: 2
  },
  feedbackNotifyToggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderTopWidth: 1,
    borderTopColor: '#26334D',
    marginTop: 10
  },

  container: {
    flex: 1,
    backgroundColor: '#0B0F17',
    paddingTop: Platform.OS === 'android' ? (StatusBar.currentHeight || 24) : 0
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#26334D',
    backgroundColor: '#0B0F17',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  logoRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  logoText: { fontSize: 18, fontWeight: '800', color: '#8B5CF6' },
  versionBadge: {
    backgroundColor: 'rgba(139, 92, 246, 0.2)',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: 'rgba(139, 92, 246, 0.4)'
  },
  versionText: { color: '#C084FC', fontSize: 11, fontWeight: '700' },
  headerRightActionsRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  headerIconBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: '#151D2A', borderWidth: 1, borderColor: '#26334D', alignItems: 'center', justifyContent: 'center' },
  headerIconBtnWithBadge: { width: 36, height: 36, borderRadius: 18, backgroundColor: '#151D2A', borderWidth: 1, borderColor: '#26334D', alignItems: 'center', justifyContent: 'center', position: 'relative' },
  unreadRedBadgeDot: { position: 'absolute', bottom: 2, right: 2, width: 10, height: 10, borderRadius: 5, backgroundColor: '#EF4444', borderWidth: 1.5, borderColor: '#0B0F17' },

  notificationCard: { backgroundColor: '#0B0F17', borderRadius: 14, borderWidth: 1, borderColor: '#26334D', padding: 12, flexDirection: 'row', alignItems: 'center', gap: 12 },
  notifAvatar: { width: 42, height: 42, borderRadius: 21, backgroundColor: '#26334D' },
  notifText: { color: '#CBD5E1', fontSize: 13, lineHeight: 18 },
  notifUserBold: { color: '#F8FAFC', fontWeight: '800' },
  notifTargetBold: { color: '#C084FC', fontWeight: '700' },
  notifTimeText: { color: '#94A3B8', fontSize: 11, marginTop: 3 },
  notifTypeIconBox: { width: 32, height: 32, borderRadius: 16, backgroundColor: '#151D2A', borderWidth: 1, borderColor: '#26334D', alignItems: 'center', justifyContent: 'center' },

  notifFollowBackBtn: { backgroundColor: '#8B5CF6', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  notifFollowBackBtnActive: { backgroundColor: 'transparent', borderWidth: 1, borderColor: '#8B5CF6' },
  notifFollowBackText: { color: '#FFFFFF', fontSize: 11, fontWeight: '700' },
  notifFollowBackTextActive: { color: '#C084FC' },

  mainViewContainer: { flex: 1 },
  scrollView: { flex: 1 },
  scrollContent: { padding: 20, paddingBottom: 110 },
  hero: { marginBottom: 16, alignItems: 'center' },
  heroBadge: {
    color: '#C084FC',
    backgroundColor: 'rgba(139, 92, 246, 0.15)',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 99,
    fontSize: 12,
    fontWeight: '700',
    marginBottom: 10
  },
  heroTitle: { fontSize: 24, fontWeight: '800', color: '#F8FAFC', textAlign: 'center', marginBottom: 8 },
  heroSubtitle: { fontSize: 13, color: '#94A3B8', textAlign: 'center', lineHeight: 20 },
  
  pageHeaderBox: { marginBottom: 12 },
  pageHeaderTitle: { fontSize: 20, fontWeight: '800', color: '#F8FAFC', marginBottom: 4 },
  pageHeaderSubtitle: { fontSize: 13, color: '#94A3B8' },

  iconTextInlineRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },

  inputWithClearRow: { flexDirection: 'row', alignItems: 'center', position: 'relative' },
  clearFieldBtn: { position: 'absolute', right: 12, width: 28, height: 28, borderRadius: 14, backgroundColor: '#0B0F17', borderWidth: 1, borderColor: '#26334D', alignItems: 'center', justifyContent: 'center', zIndex: 10 },

  storiesBarScroll: { flexDirection: 'row', marginBottom: 20 },
  storyCircleWrapper: { alignItems: 'center', marginRight: 14, width: 62 },
  storyRing: {
    width: 58, height: 58, borderRadius: 29, padding: 2.5,
    borderWidth: 2, borderColor: '#26334D', backgroundColor: '#0B0F17'
  },
  storyRingActive: { borderColor: '#8B5CF6' },
  storyAvatar: { width: '100%', height: '100%', borderRadius: 26 },
  storyNameText: { color: '#94A3B8', fontSize: 11, fontWeight: '600', marginTop: 4, textAlign: 'center' },
  storyNameTextActive: { color: '#C084FC', fontWeight: '800' },

  topCategoryBarWrapper: { marginBottom: 20 },
  topCategoryScrollView: { flexDirection: 'row' },
  topCategoryChip: {
    backgroundColor: '#151D2A', paddingHorizontal: 14, paddingVertical: 8,
    borderRadius: 99, borderWidth: 1, borderColor: '#26334D', marginRight: 8
  },
  topCategoryChipActive: { backgroundColor: '#8B5CF6', borderColor: '#8B5CF6' },
  topCategoryText: { color: '#94A3B8', fontSize: 12, fontWeight: '600' },
  topCategoryTextActive: { color: '#FFFFFF', fontWeight: '700' },
  grid2x2CategoryBtn: {
    backgroundColor: '#8B5CF6', width: 34, height: 34, borderRadius: 10,
    alignItems: 'center', justifyContent: 'center', marginRight: 16
  },

  categorySearchInput: {
    backgroundColor: '#151D2A', borderWidth: 1, borderColor: '#26334D', borderRadius: 10,
    paddingHorizontal: 14, paddingVertical: 10, color: '#F8FAFC', fontSize: 13, marginBottom: 10
  },
  selectedCategoriesRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 10 },
  selectedCategoryPill: {
    backgroundColor: '#8B5CF6', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 99
  },
  selectedCategoryText: { color: '#FFFFFF', fontSize: 11, fontWeight: '700' },
  categoryVerticalListContainer: {
    backgroundColor: '#151D2A', borderRadius: 12, borderWidth: 1, borderColor: '#26334D', padding: 8, marginBottom: 14
  },
  categoryVerticalItem: { paddingVertical: 10, paddingHorizontal: 12, borderBottomWidth: 1, borderBottomColor: '#26334D' },
  categoryVerticalItemActive: { backgroundColor: 'rgba(139, 92, 246, 0.2)' },
  categoryVerticalText: { color: '#CBD5E1', fontSize: 13, fontWeight: '600' },
  categoryVerticalTextActive: { color: '#C084FC', fontWeight: '800' },
  addCustomCategoryItemBtn: { paddingVertical: 12, alignItems: 'center', backgroundColor: '#0B0F17', borderRadius: 8, marginTop: 4 },
  addCustomCategoryItemText: { color: '#8B5CF6', fontSize: 12, fontWeight: '700' },
  moreCategoriesChip: { backgroundColor: '#0B0F17', borderWidth: 1, borderColor: '#8B5CF6', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 99 },
  moreCategoriesText: { color: '#C084FC', fontSize: 11, fontWeight: '700' },

  leftAlignedEngagementStatsRow: { flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 },
  statInlinePill: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#0B0F17', borderRadius: 10, paddingHorizontal: 10, paddingVertical: 5, borderWidth: 1, borderColor: '#26334D' },
  statInlineNumText: { color: '#F8FAFC', fontSize: 12, fontWeight: '700' },

  stickyModalTitleBar: {
    backgroundColor: '#151D2A',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#26334D',
    alignItems: 'center'
  },
  stickyModalTitleText: {
    color: '#F8FAFC',
    fontSize: 16,
    fontWeight: '800'
  },

  stickyModalBackToTopBtn: {
    position: 'absolute', bottom: 90, right: 20,
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: '#8B5CF6', alignItems: 'center', justifyContent: 'center',
    elevation: 10, shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.35, shadowRadius: 6, zIndex: 99
  },

  floatingLikeCircleBtn: {
    position: 'absolute', bottom: 28, right: 20,
    width: 52, height: 52, borderRadius: 26,
    backgroundColor: '#151D2A', borderWidth: 1, borderColor: '#26334D',
    alignItems: 'center', justifyContent: 'center',
    elevation: 12, shadowColor: '#000', shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.45, shadowRadius: 10, zIndex: 99,
    opacity: 1
  },

  customConfirmCard: {
    backgroundColor: '#151D2A', borderRadius: 20, borderWidth: 1, borderColor: '#26334D',
    padding: 24, width: '100%', maxWidth: 340, alignItems: 'center'
  },
  confirmIconCircle: { width: 48, height: 48, borderRadius: 24, backgroundColor: 'rgba(239, 68, 68, 0.15)', alignItems: 'center', justifyContent: 'center', marginBottom: 14 },
  successIconCircle: { width: 48, height: 48, borderRadius: 24, backgroundColor: 'rgba(16, 185, 129, 0.15)', alignItems: 'center', justifyContent: 'center', marginBottom: 14 },
  confirmTitle: { fontSize: 18, fontWeight: '800', color: '#F8FAFC', marginBottom: 8, textAlign: 'center' },
  confirmSubText: { fontSize: 13, color: '#94A3B8', textAlign: 'center', lineHeight: 20, marginBottom: 14 },
  linkUrlBox: { backgroundColor: '#0B0F17', borderRadius: 10, padding: 10, borderWidth: 1, borderColor: '#26334D', width: '100%', marginBottom: 20 },
  linkUrlText: { color: '#8B5CF6', fontSize: 12, textAlign: 'center', fontWeight: '600' },
  confirmActionsRow: { flexDirection: 'row', gap: 12, width: '100%' },
  confirmCancelBtn: { flex: 1, backgroundColor: '#0B0F17', borderWidth: 1, borderColor: '#26334D', paddingVertical: 12, borderRadius: 12, alignItems: 'center' },
  confirmCancelText: { color: '#94A3B8', fontSize: 13, fontWeight: '700' },
  confirmDeleteBtn: { flex: 1, backgroundColor: '#8B5CF6', paddingVertical: 12, borderRadius: 12, alignItems: 'center' },
  confirmDeleteText: { color: '#FFFFFF', fontSize: 13, fontWeight: '800' },

  overlayModalBg: { flex: 1, backgroundColor: 'rgba(11, 15, 23, 0.85)', justifyContent: 'center', alignItems: 'center', padding: 20 },
  overlayModalContainer: { backgroundColor: '#151D2A', borderRadius: 20, borderWidth: 1, borderColor: '#26334D', maxHeight: '85%', width: '100%', overflow: 'hidden' },
  accountSettingsScrollContent: { padding: 20, gap: 12 },
  saveAccountSettingsBtn: { backgroundColor: '#8B5CF6', height: 48, borderRadius: 12, alignItems: 'center', justifyContent: 'center', marginTop: 16 },

  allCategoriesGrid: { padding: 20, flexDirection: 'row', flexWrap: 'wrap', gap: 10, justifyContent: 'space-between' },
  overlayCategoryCard: { width: '48%', backgroundColor: '#0B0F17', paddingVertical: 14, paddingHorizontal: 10, borderRadius: 12, borderWidth: 1, borderColor: '#26334D', alignItems: 'center' },
  overlayCategoryCardActive: { backgroundColor: '#8B5CF6', borderColor: '#8B5CF6' },
  overlayCategoryText: { color: '#CBD5E1', fontSize: 12, fontWeight: '700' },
  overlayCategoryTextActive: { color: '#FFFFFF' },

  stickyBackToTopBtn: {
    position: 'absolute', bottom: 100, right: 20, width: 42, height: 42,
    borderRadius: 21, backgroundColor: '#8B5CF6', alignItems: 'center', justifyContent: 'center',
    elevation: 10, shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 6, zIndex: 99
  },

  emptyFollowedBox: { backgroundColor: '#151D2A', borderRadius: 16, borderWidth: 1, borderColor: '#26334D', padding: 24, alignItems: 'center', marginTop: 10 },
  emptyFollowedTitle: { fontSize: 18, fontWeight: '800', color: '#F8FAFC', marginBottom: 8, textAlign: 'center' },
  emptyFollowedSub: { fontSize: 13, color: '#94A3B8', textAlign: 'center', lineHeight: 20, marginBottom: 20 },
  discoverDesignersBtn: { backgroundColor: '#8B5CF6', paddingHorizontal: 20, paddingVertical: 12, borderRadius: 12 },
  discoverBtnText: { color: '#FFFFFF', fontSize: 13, fontWeight: '700' },

  grid: { gap: 20 },
  card: {
    backgroundColor: '#151D2A',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#26334D',
    overflow: 'hidden'
  },
  thumbnailContainer: { position: 'relative', width: '100%', height: 180, backgroundColor: '#070A10' },
  cardCover: { width: '100%', height: '100%' },
  prototypeBadgesRow: { position: 'absolute', top: 12, left: 12, flexDirection: 'row', gap: 8, zIndex: 10 },
  protoBadgeIconOnly: {
    backgroundColor: 'rgba(15, 23, 42, 0.82)',
    padding: 7,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.25)',
    alignItems: 'center',
    justifyContent: 'center'
  },
  cardBody: { padding: 16 },
  titleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 },
  cardTitle: { fontSize: 16, fontWeight: '700', color: '#F8FAFC', flex: 1, marginRight: 8 },
  likeButtonRightAligned: { padding: 4, alignSelf: 'flex-start' },
  cardDesc: { fontSize: 13, color: '#94A3B8', marginBottom: 16, lineHeight: 18 },
  
  designerRowWithFollow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderTopWidth: 1, borderTopColor: '#26334D', paddingTop: 12 },
  designerRowLeftCol: { flexDirection: 'row', alignItems: 'center', gap: 8, flex: 1, marginRight: 8 },
  designerAvatar: { width: 24, height: 24, borderRadius: 12, backgroundColor: '#26334D' },
  cardDesignerName: { color: '#C084FC', fontSize: 12, fontWeight: '600', flex: 1, flexWrap: 'wrap' },
  cardFollowBtnRight: { backgroundColor: '#8B5CF6', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  cardFollowBtnRightActive: { backgroundColor: 'transparent', borderWidth: 1, borderColor: '#8B5CF6' },
  cardFollowBtnText: { color: '#FFFFFF', fontSize: 10, fontWeight: '700' },
  cardFollowBtnTextActive: { color: '#C084FC' },

  profileTabsBar: {
    flexDirection: 'row', backgroundColor: '#151D2A', borderRadius: 12, padding: 4,
    marginVertical: 20, borderWidth: 1, borderColor: '#26334D', gap: 4
  },
  profileTabBtn: { flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: 8 },
  profileTabBtnActive: { backgroundColor: '#8B5CF6' },
  profileTabBtnText: { fontSize: 12, color: '#94A3B8', fontWeight: '700' },
  profileTabBtnTextActive: { color: '#FFFFFF' },

  twoRowContainer: { flexDirection: 'row', gap: 16 },
  twoRowColumn: { gap: 16 },
  emptyTabContainer: { paddingVertical: 24, alignItems: 'center' },

  floatingBottomBar: {
    position: 'absolute', bottom: 24, left: 20, right: 20, height: 64,
    backgroundColor: '#151D2A', borderRadius: 24, borderWidth: 1, borderColor: '#26334D',
    flexDirection: 'row', alignItems: 'center', paddingHorizontal: 6,
    shadowColor: '#000', shadowOffset: { width: 0, height: 10 }, shadowOpacity: 0.45, shadowRadius: 20, elevation: 12, zIndex: 100
  },
  uniformTabItem: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingVertical: 6 },
  menuLabel: { fontSize: 10, fontWeight: '600', color: '#94A3B8', marginTop: 2 },
  menuLabelActive: { color: '#8B5CF6', fontWeight: '700' },
  plusContainerBtn: {
    width: 44, height: 44, borderRadius: 14, backgroundColor: '#8B5CF6',
    alignItems: 'center', justifyContent: 'center', marginHorizontal: 4,
    shadowColor: '#8B5CF6', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.4, shadowRadius: 10, elevation: 6
  },

  searchContainer: { marginBottom: 20 },
  searchInput: { backgroundColor: '#151D2A', borderWidth: 1, borderColor: '#26334D', borderRadius: 12, paddingHorizontal: 16, paddingVertical: 12, color: '#F8FAFC', fontSize: 14 },
  keywordsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 10 },
  keywordChip: { backgroundColor: '#151D2A', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 99, borderWidth: 1, borderColor: '#26334D' },
  keywordText: { color: '#D8B4FE', fontSize: 12, fontWeight: '600' },
  designersList: { gap: 12 },
  designerItemCard: { backgroundColor: '#151D2A', borderRadius: 14, borderWidth: 1, borderColor: '#26334D', padding: 14, flexDirection: 'row', alignItems: 'center' },
  designerListAvatar: { width: 48, height: 48, borderRadius: 24, marginRight: 12 },
  designerInfoCol: { flex: 1 },
  designerListName: { fontSize: 15, fontWeight: '700', color: '#F8FAFC', marginBottom: 2 },
  designerListRole: { fontSize: 12, color: '#C084FC', fontWeight: '600', marginBottom: 2 },
  designerListLoc: { fontSize: 11, color: '#94A3B8' },
  emptySearchText: { color: '#94A3B8', fontSize: 13, marginTop: 20 },

  designerCardActionsRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 8 },
  smallFollowBtn: { flex: 1, backgroundColor: '#8B5CF6', paddingVertical: 6, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  smallFollowBtnActive: { backgroundColor: 'transparent', borderWidth: 1.5, borderColor: '#8B5CF6' },
  smallFollowText: { color: '#FFFFFF', fontSize: 11, fontWeight: '700' },
  smallFollowTextActive: { color: '#C084FC' },
  smallShareBtnIconOnly: { width: 32, height: 32, backgroundColor: '#0B0F17', borderRadius: 8, borderWidth: 1, borderColor: '#26334D', alignItems: 'center', justifyContent: 'center' },

  statsRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginVertical: 14, backgroundColor: '#0B0F17', borderRadius: 12, paddingVertical: 10, paddingHorizontal: 20, gap: 20, borderWidth: 1, borderColor: '#26334D' },
  statItem: { alignItems: 'center', paddingHorizontal: 12 },
  statNum: { fontSize: 16, fontWeight: '800', color: '#F8FAFC' },
  statLabel: { fontSize: 11, color: '#94A3B8', fontWeight: '600', marginTop: 2 },
  statDivider: { width: 1, height: 24, backgroundColor: '#26334D' },

  designerProfileActionsRow: { flexDirection: 'row', gap: 10, marginTop: 12, width: '100%', alignItems: 'center' },
  modalFollowBtn: { flex: 1, backgroundColor: '#8B5CF6', paddingVertical: 12, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  modalFollowBtnActive: { backgroundColor: 'transparent', borderWidth: 1.5, borderColor: '#8B5CF6' },
  modalFollowText: { color: '#FFFFFF', fontSize: 13, fontWeight: '700' },
  modalFollowTextActive: { color: '#C084FC' },
  modalShareBtnIconOnly: { width: 44, height: 44, backgroundColor: '#0B0F17', borderWidth: 1, borderColor: '#26334D', borderRadius: 12, alignItems: 'center', justifyContent: 'center' },

  categoryPillsRow: { flexDirection: 'row', gap: 8, marginBottom: 14, flexWrap: 'wrap' },
  categoryPill: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 99, backgroundColor: '#151D2A', borderWidth: 1, borderColor: '#26334D' },
  categoryPillActive: { backgroundColor: '#8B5CF6', borderColor: '#8B5CF6' },
  categoryPillText: { color: '#94A3B8', fontSize: 12, fontWeight: '600' },
  categoryPillTextActive: { color: '#FFFFFF' },

  profileCard: { backgroundColor: '#151D2A', borderRadius: 16, borderWidth: 1, borderColor: '#26334D', padding: 24, alignItems: 'center', position: 'relative' },
  profileTopRightShareBtn: { position: 'absolute', top: 16, right: 16, width: 36, height: 36, borderRadius: 18, backgroundColor: '#0B0F17', borderWidth: 1, borderColor: '#26334D', alignItems: 'center', justifyContent: 'center', zIndex: 10 },
  profileLargeAvatar: { width: 80, height: 80, borderRadius: 40, marginBottom: 12 },
  profileName: { fontSize: 20, fontWeight: '800', color: '#F8FAFC', marginBottom: 4, textAlign: 'center' },
  profileRole: { fontSize: 13, color: '#C084FC', fontWeight: '600', marginBottom: 2 },
  profileLocText: { fontSize: 12, color: '#94A3B8' },
  profileBio: { fontSize: 13, color: '#94A3B8', textAlign: 'center', lineHeight: 20, marginBottom: 8 },

  socialCircularLinksRow: { flexDirection: 'row', gap: 10, marginTop: 14, justifyContent: 'center' },
  socialCircleBtn: { width: 38, height: 38, borderRadius: 19, backgroundColor: '#0B0F17', borderWidth: 1, borderColor: '#26334D', alignItems: 'center', justifyContent: 'center' },
  socialCirclePreviewBtn: { width: 42, height: 42, borderRadius: 21, backgroundColor: '#0B0F17', borderWidth: 1, borderColor: '#26334D', alignItems: 'center', justifyContent: 'center' },

  avatarEditPickerBtn: { alignSelf: 'center', width: 90, height: 90, borderRadius: 45, overflow: 'hidden', position: 'relative', marginBottom: 10 },
  avatarEditPreview: { width: '100%', height: '100%' },
  avatarEditOverlay: { position: 'absolute', bottom: 0, left: 0, right: 0, backgroundColor: 'rgba(11, 15, 23, 0.75)', paddingVertical: 4, alignItems: 'center' },
  avatarEditText: { color: '#C084FC', fontSize: 9, fontWeight: '700' },

  settingItemRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#26334D' },
  settingToggleRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#26334D' },
  settingItemTitle: { color: '#F8FAFC', fontSize: 14, fontWeight: '700' },
  settingItemSub: { color: '#94A3B8', fontSize: 11, marginTop: 2, lineHeight: 16 },
  settingItemValue: { color: '#C084FC', fontSize: 13, fontWeight: '600' },

  smallSquaresGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 10 },
  squarePickerWrapper: { position: 'relative' },
  removeImageBadge: { position: 'absolute', top: -6, right: -6, width: 26, height: 26, borderRadius: 13, backgroundColor: '#0B0F17', borderWidth: 1, borderColor: '#EF4444', alignItems: 'center', justifyContent: 'center', zIndex: 10 },
  videoInputRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 },
  removeVideoBtn: { width: 42, height: 42, backgroundColor: '#0B0F17', borderWidth: 1, borderColor: '#EF4444', borderRadius: 10, alignItems: 'center', justifyContent: 'center' },

  ownerActionsRow: { flexDirection: 'row', gap: 8, marginRight: 10 },
  ownerIconBtn: { width: 32, height: 32, borderRadius: 16, backgroundColor: '#0B0F17', borderWidth: 1, borderColor: '#26334D', alignItems: 'center', justifyContent: 'center' },

  stepProgressBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 20, paddingVertical: 12, backgroundColor: '#151D2A',
    borderBottomWidth: 1, borderBottomColor: '#26334D'
  },
  stepProgressItem: { alignItems: 'center', gap: 4 },
  stepLabel: { fontSize: 10, color: '#94A3B8', fontWeight: '600' },
  stepLabelActive: { color: '#8B5CF6', fontWeight: '800' },
  stepDivider: { flex: 1, height: 1, backgroundColor: '#26334D', marginHorizontal: 6, marginBottom: 12 },
  stepSectionTitle: { fontSize: 16, fontWeight: '800', color: '#F8FAFC', marginBottom: 16 },

  warningNoteBox: {
    backgroundColor: 'rgba(234, 179, 8, 0.12)', borderWidth: 1, borderColor: 'rgba(234, 179, 8, 0.3)',
    borderRadius: 10, padding: 12, marginBottom: 16
  },
  warningTitle: { color: '#FACC15', fontSize: 13, fontWeight: '700' },
  warningText: { color: '#CBD5E1', fontSize: 12, lineHeight: 18, marginTop: 4 },

  inputErrorBorder: { borderColor: '#EF4444' },
  errorText: { color: '#EF4444', fontSize: 11, fontWeight: '600', marginTop: 4, marginBottom: 8 },

  bigRectanglePicker: {
    width: '100%', height: 140, backgroundColor: '#151D2A', borderRadius: 14,
    borderWidth: 1.5, borderColor: '#26334D', borderStyle: 'dashed',
    overflow: 'hidden', alignItems: 'center', justifyContent: 'center'
  },
  bigRectanglePreview: { width: '100%', height: '100%' },
  pickerPlaceholderCol: { alignItems: 'center', padding: 12, gap: 4 },
  pickerTextMain: { color: '#F8FAFC', fontSize: 13, fontWeight: '700' },
  pickerSubText: { color: '#94A3B8', fontSize: 11 },

  smallSquarePicker: {
    width: 80, height: 80, backgroundColor: '#151D2A', borderRadius: 12,
    borderWidth: 1.5, borderColor: '#26334D', borderStyle: 'dashed',
    overflow: 'hidden', alignItems: 'center', justifyContent: 'center'
  },
  smallSquarePreview: { width: '100%', height: '100%' },
  squarePickerText: { color: '#94A3B8', fontSize: 10, fontWeight: '600', marginTop: 2 },

  addMoreVideoBtn: {
    backgroundColor: 'rgba(139, 92, 246, 0.15)', borderWidth: 1, borderColor: 'rgba(139, 92, 246, 0.3)',
    paddingVertical: 10, borderRadius: 8, alignItems: 'center', justifyContent: 'center', marginTop: 4
  },
  addMoreVideoText: { color: '#D8B4FE', fontSize: 12, fontWeight: '700' },

  stickyWizardBottomBar: {
    height: 72,
    backgroundColor: '#151D2A', borderTopWidth: 1, borderTopColor: '#26334D',
    flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, gap: 10
  },
  uniformWizardBtnBack: {
    height: 48, backgroundColor: '#0B0F17', borderWidth: 1, borderColor: '#26334D',
    paddingHorizontal: 16, borderRadius: 12, alignItems: 'center', justifyContent: 'center'
  },
  uniformWizardBtnSkip: {
    height: 48, borderWidth: 1, borderColor: '#8B5CF6',
    paddingHorizontal: 16, borderRadius: 12, alignItems: 'center', justifyContent: 'center'
  },
  uniformWizardBtnPrimary: {
    height: 48, backgroundColor: '#8B5CF6', flex: 1,
    borderRadius: 12, alignItems: 'center', justifyContent: 'center'
  },
  backBtnText: { color: '#94A3B8', fontSize: 13, fontWeight: '700' },
  skipBtnText: { color: '#C084FC', fontSize: 13, fontWeight: '700' },
  submitBtnText: { color: '#FFFFFF', fontSize: 14, fontWeight: '800' },

  confirmReviewCard: {
    backgroundColor: '#151D2A', borderRadius: 14, borderWidth: 1, borderColor: '#26334D',
    padding: 16, marginBottom: 16
  },
  reviewCover: { width: '100%', height: 160, borderRadius: 10, marginBottom: 12 },
  reviewTitle: { fontSize: 18, fontWeight: '800', color: '#F8FAFC', marginBottom: 2 },
  reviewDesigner: { fontSize: 12, color: '#C084FC', fontWeight: '600', marginBottom: 8 },
  reviewCategory: { fontSize: 12, color: '#94A3B8', marginBottom: 8 },
  reviewBrief: { fontSize: 13, color: '#CBD5E1', lineHeight: 18, marginBottom: 14 },
  reviewSummaryRow: { borderTopWidth: 1, borderTopColor: '#26334D', paddingTop: 10, gap: 4 },
  reviewStat: { fontSize: 12, color: '#94A3B8', fontWeight: '600' },

  modalContainer: { flex: 1, backgroundColor: '#0B0F17' },
  modalTopBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#26334D', backgroundColor: '#151D2A' },
  modalTopTitle: { fontSize: 16, fontWeight: '700', color: '#F8FAFC', flex: 1 },
  closeBtn: { width: 32, height: 32, borderRadius: 16, backgroundColor: '#0B0F17', borderWidth: 1, borderColor: '#26334D', alignItems: 'center', justifyContent: 'center' },
  closeBtnText: { color: '#FFF', fontSize: 16, fontWeight: '700' },
  tabBar: { flexDirection: 'row', backgroundColor: '#151D2A', padding: 6, marginHorizontal: 16, marginVertical: 10, borderRadius: 12, gap: 6 },
  tabBtn: { flex: 1, paddingVertical: 8, alignItems: 'center', borderRadius: 8 },
  tabBtnActive: { backgroundColor: '#8B5CF6' },
  tabBtnText: { color: '#94A3B8', fontSize: 12, fontWeight: '700' },
  tabBtnTextActive: { color: '#FFF' },
  modalBody: { flex: 1 },
  webViewWrapper: { flex: 1, position: 'relative' },
  webView: { flex: 1, backgroundColor: '#000' },
  loaderOverlay: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: '#0B0F17', alignItems: 'center', justifyContent: 'center', zIndex: 10 },
  loaderText: { color: '#94A3B8', fontSize: 13, marginTop: 12, fontWeight: '600' },
  caseScrollView: { flex: 1 },
  caseContent: { padding: 20 },
  caseTitle: { fontSize: 22, fontWeight: '800', color: '#F8FAFC', marginBottom: 4 },
  designerRowModal: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10, marginBottom: 14 },
  designerRowModalLeftCol: { flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1, marginRight: 8 },
  designerAvatarModal: { width: 36, height: 36, borderRadius: 18, backgroundColor: '#26334D' },
  caseDesigner: { fontSize: 14, color: '#C084FC', fontWeight: '700' },
  caseDesignerRole: { fontSize: 11, color: '#94A3B8', fontWeight: '600' },
  modalDesignerFollowBtnRight: { backgroundColor: '#8B5CF6', paddingHorizontal: 14, paddingVertical: 7, borderRadius: 10 },
  modalDesignerFollowBtnRightActive: { backgroundColor: 'transparent', borderWidth: 1, borderColor: '#8B5CF6' },
  modalDesignerFollowTextRight: { color: '#FFFFFF', fontSize: 12, fontWeight: '700' },
  modalDesignerFollowTextRightActive: { color: '#C084FC' },

  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 16 },
  linkChip: { backgroundColor: '#151D2A', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 8, borderWidth: 1, borderColor: '#26334D' },
  linkChipText: { color: '#D8B4FE', fontSize: 12, fontWeight: '600' },
  briefBox: { backgroundColor: 'rgba(30, 41, 59, 0.5)', borderLeftWidth: 4, borderLeftColor: '#8B5CF6', padding: 14, borderRadius: 8, marginBottom: 20 },
  briefText: { color: '#F8FAFC', fontSize: 14, lineHeight: 20 },
  sectionHeader: { fontSize: 12, fontWeight: '800', color: '#94A3B8', letterSpacing: 1, marginBottom: 12, marginTop: 10 },
  galleryScroll: { marginBottom: 24 },
  galleryImage: { width: 200, height: 320, borderRadius: 12, marginRight: 12 },
  caseBodyText: { color: '#94A3B8', fontSize: 14, lineHeight: 22 },
  formGroupLabel: { fontSize: 13, fontWeight: '700', color: '#F8FAFC', marginBottom: 6, marginTop: 12 },
  formInput: { backgroundColor: '#151D2A', borderWidth: 1, borderColor: '#26334D', borderRadius: 10, paddingHorizontal: 14, paddingVertical: 10, color: '#F8FAFC', fontSize: 13 }
});